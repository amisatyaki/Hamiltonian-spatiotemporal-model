% create Data.mat for matlab
% use import button to import locations.txt, latent.txt and response.txt
% generated and saved by mixtureGPs.R as matrices NOT as tables
% 
s= locations; % it is of dimension 50 x 2
T= 1:20;
T= T'; % it is of dimension 20 x 1
X= latent; % it is of dimension 50 x 21
Y= response; % it is of dimension 50 x 21
Data = {s, T, X, Y}; % this creates a cell of dimension 1 x 4
save Data
clear s T X Y 
