train_test_funct = function(Piemonte_data,n_days){
	testdata=data.frame
	testdata = Piemonte_data[1,]
	traindata = data.frame
	traindata = Piemonte_data[1,]
	for (i in 1:n_days){
		testdata[(1+4*(i-1)):(4+4*(i-1)),] = Piemonte_data[(21+24*(i-1)):(24+24*(i-1)),]
		traindata[(1+20*(i-1)):(20+20*(i-1)),] = Piemonte_data[(1+24*(i-1)):(20+24*(i-1)),]
		#print(i)
	}
	splitted_data = list(traindata,testdata)
	return(splitted_data)
}
