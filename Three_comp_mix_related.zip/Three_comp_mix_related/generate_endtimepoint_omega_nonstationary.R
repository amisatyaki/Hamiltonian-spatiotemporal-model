generate_endtimepoint_omega_nonstationary = function(n_days,n_stations,sigma2,D1,ar,alpha,kappa){
	# sigma2 is here a vector of length n_station
	# theta is a vector containing three components, theta1, theta2 and theta3
	var.ar = sigma2/(1-ar^2)
	omega = rmvnorm(1,rep(0,n_stations),diag(c(var.ar)))	
	#locn = mesh$idx$loc
	
	#for (t in 2:n_days){
	#	Q = inla.spde2.precision(spde=spde,theta=theta)
	#	xi = as.vector(inla.qsample(n=n_days,Q))
	#	xi=as.vector(A%*%xi)
	#	omega = omega%*%(ar*diag(n_stations)) + xi
	#}
	mean.xi = rep(0,n_stations)
	cov.xi = matern.covariance(D1,kappa,alpha-1,sqrt(1))
	cov.xi = diag(c(sqrt(sigma2)))%*%cov.xi%*%diag(c(sqrt(sigma2)))
	for (t in 2:n_days){
		xi = rmvnorm(1,mean.xi,cov.xi)
		omega = omega%*%(ar*diag(n_stations)) + xi
	}

	return(omega)
} 


