function betastar=update_beta_TMCMC(sigma_beta,betastar,c1,c2)


p=0.5;
q=0.5;
%
%%%%%%%%  %%%%%%%%%%
U=unifrnd(0,1,1);
a_j1 = 0.05;


log_prior = (-betastar^2)/(2*sigma_beta^2);
beta = (exp(2*betastar)-1)/(exp(2*betastar)+1);%-1+(2*exp(betastar)/(1+2*exp(betastar)));
log_g = (-beta^2)*c1+beta*c2;
log_denom = log_prior + log_g;
phi_tilde = betastar;

if (U<p) 
   epsilon=normrnd(0,1,1);
   a=unidrnd(2);
   b_j = -1*(a==1)+1*(a==2);
   delta = betastar+b_j*a_j1*abs(epsilon);
   log_prior = (-delta^2)/(2*sigma_beta^2);
   beta = (exp(2*delta)-1)/(exp(2*delta)+1);%-1+(2*exp(delta)/(1+2*exp(delta)));
   log_g = (-beta^2)*c1+beta*c2;
   log_num = log_prior + log_g;
   log_diff = log_num - log_denom;
   pi1 = exp(log_diff);
    if (unifrnd(0,1)<=pi1)
        phi_tilde = delta;
    end
end
b=0;
if(U>=p)
   epsilon = unifrnd(-1,1);
       a=unidrnd(3);
       b_j = -1*(a==1) + 0*(a==2)+1*(a==3);
       delta = betastar*epsilon*(b_j==-1)+(betastar/epsilon)*(b_j==-1)+...
               betastar*(b_j==0);
       b=b+b_j;
   J = abs(epsilon)^b;
   log_prior = (-delta^2)/(2*sigma_beta^2);
   beta = (exp(2*delta)-1)/(exp(2*delta)+1);
   log_g = (-beta^2)*c1+beta*c2;
   log_num = log_prior + log_g + log(J);
   log_diff = log_num - log_denom;
   pi2 = exp(log_diff);
   if (unifrnd(0,1)<=pi2)
       phi_tilde = delta;
    end
end

log_prior = (-phi_tilde^2)/(2*sigma_beta^2);
beta = (exp(2*phi_tilde)-1)/(exp(2*phi_tilde)+1);
log_g = (-beta^2)*c1+beta*c2;
log_denom = log_prior + log_g;

aj_2 = 0.05;

betastar = phi_tilde; 

U=unifrnd(0,1);
if (U< q)
    U_tilde = unifrnd(0,1);
    epsilon = normrnd(0,1);
        delta = (phi_tilde + aj_2*abs(epsilon))*(U_tilde<=0.5) + ...
            (phi_tilde - aj_2*abs(epsilon))*(U_tilde>0.5);
   log_prior = (-delta^2)/(2*sigma_beta^2);
   beta = (exp(2*delta)-1)/(exp(2*delta)+1);%-1+(2*exp(delta)/(1+2*exp(delta)));
   log_g = (-beta^2)*c1+beta*c2;    
    log_num = log_prior + log_g;
    log_diff = log_num - log_denom;
    pi3 = exp(log_diff);
    if(unifrnd(0,1)<=pi3)
       betastar = delta;
    end
end

if (U>=q)
    U_tilde = unifrnd(0,1);
    epsilon = unifrnd(-1,1);
        delta = (phi_tilde*epsilon)*(U_tilde<=0.5) + ...
            (phi_tilde/epsilon)*(U_tilde>0.5);
    J = abs(epsilon)^(1)*(U_tilde<=0.5) + abs(epsilon)^(-1)*(U_tilde>0.5);    
    log_prior = (-delta^2)/(2*sigma_beta^2);
    beta = (exp(2*delta)-1)/(exp(2*delta)+1);
    log_g = (-beta^2)*c1+beta*c2;
    log_num = log_prior + log_g + log(J);
    log_diff = log_num - log_denom;
    pi4 = exp(log_diff);    
    if(unifrnd(0,1)<=pi4)
       betastar = delta;
    end    
end
