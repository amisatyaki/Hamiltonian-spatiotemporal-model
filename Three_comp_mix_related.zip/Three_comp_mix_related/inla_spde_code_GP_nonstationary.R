rm(list=ls())
library('INLA')
library('pracma')
library('rSPDE')
library('mvtnorm')
library('ggplot2')
#setwd("SPDE_spatio_temporal_modeling_example_INLA/")
set.seed(101)
# import the data set
GP_data = read.table('~/response.txt')
coordinates = read.table('~/locations.txt',sep="")

GP_data = as.matrix(GP_data)
#GP_data=GP_data[,-1]
GP_data=Reshape(GP_data,20*50,1)
GP_data = as.data.frame(GP_data)


# Change the names of the columns
colnames(coordinates)[1] = "s1"
colnames(coordinates)[2] = "s2"
colnames(GP_data)[1]="ydata"

# extract the number of observations
n_data = length(GP_data$ydata)
n_stations = length(coordinates$s1)
n_days = n_data/n_stations

# add time column to the data set
GP_data$time = rep(1:n_days,each=n_stations)
GP_data$station.ID = rep(1:n_stations,n_days)

# split the data into train and test set
 source('train_test_funct.R') # no use for us

#************another kind of split ********************************#
# split the data so that data for the last day works as test data
 learningdata = GP_data[1:(n_data-n_stations),]
 testingdata = GP_data[((n_data-n_stations)+1):n_data,]
#******************************************************************#

# creation of mesh
GP_mesh = inla.mesh.2d(loc=cbind(coordinates$s1,coordinates$s2),max.edge=25)

# creation of Matern SPDE
# ---- for nonstationary model --- #
GP_spde = inla.spde2.matern(mesh = GP_mesh,B.tau=matrix(cbind(0,1,0,sin(pi*GP_mesh$loc[,1])),ncol=4),B.kappa=matrix(c(0,0,1,0),nrow=1,ncol=4),
			theta.prior.mean=c(0,0,0),theta.prior.prec = c(0.1,0.1,0.1),alpha=2) 



# creation of locations for training data
coordinates.allyear=as.matrix(coordinates[learningdata$station.ID,c("s1","s2")])

# Calculate the A matrix for the given data
A_est = inla.spde.make.A(mesh=GP_mesh,loc=coordinates.allyear,group=learningdata$time,n.group = n_days)

# creation of locations for test data
coordinates.allyear.pred = as.matrix(coordinates[testingdata$station.ID,c("s1","s2")])

# Calculate the A matrix for test set
A_pred=inla.spde.make.A(mesh=GP_mesh,loc=coordinates.allyear.pred,group=testingdata$time,n.group=n_days)

# Creation of index at per the mesh number and time points
s_index=inla.spde.make.index(name="spatial_field",n.spde=GP_spde$n.spde,n.group=n_days)



# Creation of stack for the training data
stack_est = inla.stack(data=list(ydata = learningdata$ydata),A=list(A_est),effects=list(c(s_index)),tag="est")

# Creation of stack for test data
stack_pred = inla.stack(data = list(ydata=NA),A=list(A_pred),effects=list(c(s_index)),tag="pred")


stack=inla.stack(stack_est,stack_pred)


# Defining the formula for mean of y
formula = ydata~ f(spatial_field,model = GP_spde, group = spatial_field.group, control.group =list(model = "ar1"))

# Run the inla function
output = inla(formula, data = inla.stack.data(stack,spde = GP_spde),family="gaussian",control.predictor = list(A=inla.stack.A(stack),compute=TRUE),verbose=TRUE)

# ************* Extract the information *******************
names(output$marginals.fixed)
# "(Intercept)"
 beta0.post = output$marginals.fixed$"(Intercept)"
plot(beta0.post,type='l')
#beta0.post # this gives the probabilities (not marginalized) at possible values
beta0.post.sample = inla.rmarginal(500,beta0.post)

names(output$marginals.hyperpar)



sigma2e_marg = inla.tmarginal(function(x) 1/x,output$marginals.hyperpar[[1]])
sigma2e_sample=inla.rmarginal(500,sigma2e_marg)
 
theta1=output$marginals.hyperpar[[2]]
theta2=output$marginals.hyperpar[[3]]
theta3=output$marginals.hyperpar[[4]]
ar=output$marginals.hyperpar[[5]]

# generate samples from posteriors

ar.post.sample = inla.rmarginal(500,ar)
theta1.post.sample=inla.rmarginal(500,theta1)
theta2.post.sample=inla.rmarginal(500,theta2)
theta3.post.sample=inla.rmarginal(500,theta3)
kappa.sample = exp(theta2.post.sample)


tao.sample=c()
sigma2.sample = array(0,dim=c(n_stations,500))
for (i in 1:500){
	tao.sample = exp(theta1.post.sample[i] + theta3.post.sample[i]*sin(coordinates$s1))
	sigma2.sample[,i] = 1/(4*pi*kappa.sample[i]^2*tao.sample^2)
}

# posterior predictive calculation

source('generate_endtimepoint_omega_nonstationary.R')

loc=as.matrix(coordinates)
colnames(loc)=NULL
D1=as.matrix(dist(loc))
dim(D1) # should be a n_stations x n_stations matrix

y_pred = array(0,dim=c(500,n_stations))
omega = array(0,dim=c(500,n_stations))

for (i in 1:500){
	omega[i,] = generate_endtimepoint_omega_nonstationary(n_days,n_stations,sigma2.sample[,i],D1,ar.post.sample[i],2,kappa.sample[i])
	mean.y.fix = beta0.post.sample[i]
	mean.y = mean.y.fix*rep(1,n_stations) + omega[i,]
	y_pred[i,]=rmvnorm(1,mean.y,sigma2e_sample[i]*diag(n_stations)) 
#	print(i)
}



names=formatC(seq(1:50),width=2,flag="0")


for (s in 1:50){
	L=quantile(y_pred[,s],0.025)
	U=quantile(y_pred[,s],0.975)
	df=data.frame(value=y_pred[,s])
	myplot=ggplot(df,aes(x=value)) + geom_density(color="blue") + lims(x=c(min(y_pred[,s]),max(y_pred[,s])))+geom_segment(aes(x=L, y=0,xend=U, yend=0, lwd=3, color="red"))+
	geom_vline(xintercept=testingdata$ydata[s],lwd=1,color="black")
	ggsave(paste("response_pred",names[s],".png",sep=""),plot=myplot)
	print(paste("length = ", U-L))
	print(paste("var = ", var(y_pred[,s])))
}





GP_latentdata = read.table('~/latent.txt')
GP_latentdata = as.matrix(GP_latentdata);

testinglatentdata = GP_latentdata[,n_days]

for (s in 1:50){
	L=quantile(omega[,s],0.025)
	U=quantile(omega[,s],0.975)
	df=data.frame(value=omega[,s])
	myplot=ggplot(df,aes(x=value)) + geom_density(color="blue") + lims(x=c(min(omega[,s]),max(omega[,s])))+geom_segment(aes(x=L, y=0,xend=U, yend=0, lwd=3, color="red"))+
	geom_vline(xintercept=testinglatentdata[s],lwd=1,color="black")
	ggsave(paste("latent_pred",names[s],".png",sep=""),plot=myplot)
	print(paste("upper = ", U))
	print(paste("lower = ", L))	
	
}





