function sigma_p = fcd_sigma_p(alpha_p, gamma_p, x_0,Omega0,m,ridge)
%
%
x=x_0;
if(det(Omega0)<1e-6)
    Omega0=Omega0+ridge*eye(m);
end
scale = (gamma_p + (x'/(Omega0))*x)/2;
shape = alpha_p+m/2;
k=gamrnd(shape,1./scale);
sigma_p = sqrt(1./k);
