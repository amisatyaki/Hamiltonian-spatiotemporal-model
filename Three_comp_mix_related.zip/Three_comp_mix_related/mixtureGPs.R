mixtureGPs = function(nmode,b0,sigma2_e,a,kappa,sigma2,alpha,m,T,p){

coordinates = c(runif(m),runif(m))
loc=matrix(coordinates,m)
colnames(loc)=NULL
D1=as.matrix(dist(loc))

omega = list()
for (l in 1:nmode){
	omega[[l]] = matrix(0,m,(T+1))
}
x = matrix(0,m,T)
mean.xi = rep(0,m)
y=matrix(0,m,T)
for (t in 2:(T+1)){
	for (l in 1:nmode){
		cov.xi = matern.covariance(D1,kappa[l],alpha-1,sqrt(sigma2[l]))
		xi = rmvnorm(1,mean.xi,cov.xi)
		omega[[l]][,t] = omega[[l]][,(t-1)]%*%(a[l]*diag(m)) + xi
	}	
}
rm(t,l,xi)
prop = cumsum(p)
prop = c(0,prop,1)
for (s in 1:m){
	u = runif(1)			
	for(t in 1:T){	
		#u = runif(1)
		for (l in 1:nmode){
			if(u>prop[l] && u<=prop[l+1]){
				y[s,t] = rnorm(1,b0[l]+omega[[l]][s,(t+1)],sqrt(sigma2_e[l]))
				x[s,t] = omega[[l]][s,(t+1)]
			}
			
		}			
	}
}
rm(s,t,l)
dataset = list(loc,x,y)
return(dataset)
}
#-------------------- #
library('pracma')
library('rSPDE')
library('mvtnorm')
library('ggplot2')

set.seed(4200)

nmode=3

b0.1 = 0
b0.2 = 10
b0.3 = 20
b0 = c(b0.1,b0.2,b0.3)
sigma2_e.1 = 1.0
sigma2_e.2 = 0.01
sigma2_e.3 = 2.0
sigma2_e = c(sigma2_e.1,sigma2_e.2,sigma2_e.3)

a1 = -0.75
a2 = 0.75
a3 = 0.25
a=c(a1,a2,a3)
kappa.1 = 1
kappa.2 = 1.5
kappa.3 = 2
kappa = c(kappa.1,kappa.2,kappa.3)

sigma2.1 = 1
sigma2.2 = 2
sigma2.3 = 0.2
sigma2 = c(sigma2.1,sigma2.2,sigma2.3)

alpha=2
m=50
T=20
p1=1/3
p2=1/3
p=c(p1,p2)

dataset = mixtureGPs(nmode,b0,sigma2_e,a,kappa,sigma2,alpha,m,T,p)
coordinates = dataset[[1]]
latent = dataset[[2]]
response=dataset[[3]]
write.table(coordinates, 'locations.txt',row.names=FALSE,col.names=FALSE,sep=" ")
write.table(latent, 'latent.txt',row.names=FALSE,col.names=FALSE,sep=" ")
write.table(response, 'response.txt',row.names=FALSE,col.names=FALSE,sep=" ")



