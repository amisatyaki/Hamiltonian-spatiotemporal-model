source("ranjanda2.R")

########## for simulated data ##############

# the hpd plots will save in a folder called hpd_color_plot within
# the folder Three_comp_mix_related
# So, a folder named hpd_color_plot has to be created within Three_comp_mix_related

ff <- list.files(path="~/latent_posterior", full.names=TRUE)
myfilelist <- lapply(ff, read.table)
names(myfilelist) <- list.files(path="~/latent_posterior", full.names=FALSE)

true_data = myfilelist[[1]]
n = dim(true_data)

SIZE<-length(2:(n[2]-1))


names = formatC(seq(1:50), width=2, flag="0") ## Gives a sequence of strings 1 to 50


for(i in 2:51){
  true = t(true_data[i-1,2:(n[2]-1)])
  latent_data = t(myfilelist[[i]])

  mypath <- file.path("/home","satyaki","Three_comp_mix_related","hpd_color_plot",paste("latent_x",names[i-1], ".png", sep = ""))

  png(file=mypath)
     mytitle = paste("Posterior density of latent process: L",names[i-1])
     parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 24,a=-5,b=5)
     par(new=T)
     plot(true,type="o",pch='*',xlim=c(1,SIZE),ylim=c(-5,5),xlab="",ylab=" ",axes=FALSE,col="black",lwd=3,main=mytitle)
  dev.off()
}



