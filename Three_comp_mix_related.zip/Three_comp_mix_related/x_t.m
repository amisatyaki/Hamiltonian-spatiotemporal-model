function xt=x_t(x,m,alpha, Omega,sigma,t,ridge)
%
Omega = (sigma^2/4).*Omega;
b=det(Omega);
if b<1e-6
    Omega=Omega+ridge*eye(m);
end

mu = (alpha^2)*x(:,t-1);

xt=mvnrnd(mu,Omega)';


