function sigma = fcd_sigma(alpha_v, gamma_v, zeta, m,T)
%
scale = gamma_v/2 + 2*zeta;
shape = alpha_v+m*T;
k=gamrnd(shape,1./scale);
sigma = sqrt(1./k);
