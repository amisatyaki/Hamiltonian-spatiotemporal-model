% this creates predictive density plots for the latent variable
% x_{T+1} at all the locations
% Also the credible lengths are printed
%
x_predict = list{1,12};

x_obsd = Data{1,3}(:,end);
%% For simulated data with 50 locations
figure(1)
 for k=1:25
     subplot(5,5,k), [f,x] = ksdensity(x_predict(k,:)); plot(x,f);
     ylim([0, max(f)+0.001])
     hold on
     L = quantile(x_predict(k,:),0.025);
     U=quantile(x_predict(k,:),0.975);
     plot([L,U],[0,0],'r','LineWidth',3)
     plot([x_obsd(k),x_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
     hold off
     U-L
%     
 end
figure(2)
for k=26:50
    subplot(5,5,k-25), [f,x] = ksdensity(x_predict(k,:)); plot(x,f);
    ylim([0, max(f)+0.001])
    hold on
    L = quantile(x_predict(k,:),0.025);
    U=quantile(x_predict(k,:),0.975);
    plot([L,U],[0,0],'r','LineWidth',3)
    plot([x_obsd(k),x_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
    hold off
    U-L
%    
end
