# data were in .mat format
library(R.matlab)
source("ranjanda2.R")
# 
y_mult_predict = readMat("y_multi_predict.mat") # data were saved in cell
aa=y_mult_predict[[1]] # it is matrix of lists containing 16 lists for 16 locations
n=length(aa)

true_data = readMat("detrended_data_16locations.mat") # true data for 16 locations after detrending, 16 x 7 dimensional #data
true_data = true_data$ymulttrue

names = formatC(c(2016,2017,2018,2019,2020,2021)) ## Gives a sequence of strings of length 6 from 2016 to 2021
SIZE = n # this is needed for Ranjandar.R code


bb = aa[1] # this is the ith list corresponding to the first location
cc=bb[[1]] # this is again a list
dd=cc[[1]] # this finally the data matrix containing 7 x 25000 data points corresponding to first location and 7 time points
N0 = dim(dd)
N0=N0[2]
A = array(0,c(n,N0))

t=1
A[1,] = dd[t+1,] # stores datamatrix 16x 25000 corresponding to timepoint t, starting from 2

for (i in 2:n){
        bb=aa[i] # this is the ith list corresponding to the first location
        cc=bb[[1]] # this is again a list
        dd=cc[[1]] # this finally the data matrix containing 7 x 25000 data points corresponding to first location and 7 time points
        A[i,] = dd[t+1,] # stores datamatrix 16x 25000 corresponding to timepoint t, starting from 2
}
true = true_data[,t+1] # observed detrended data at 16 locations starting from time point 2
mypath <- file.path("/home","Alaska_related",paste("multitimepoint_y",names[t], ".png", sep = ""))
#
png(file=mypath)
mytitle = paste("Predictive density of temperature at year",names[t])
parallel.empirical.plot(x.data = t(A), plcolor = "maroon", Ncl = 8,a=-8,b=8)
par(new=T)
plot(true,pch='*',xlim=c(1,n),ylim=c(-8,8),xlab="",ylab=" ",axes=FALSE,col="black",cex=3,main=mytitle)
dev.off()


for (t in 2:6){
    A = array(0,c(n,N0))
    for (i in 1:n){
        bb=aa[i] # this is the fist list corresponding to the first location
        cc=bb[[1]] # this is again a list
        dd=cc[[1]] # this finally the data matrix containing 7 x 25000 data points corresponding to first location and 7 time points
        A[i,] = dd[t+1,] # stores datamatrix 16x 25000 corresponding to timepoint t, starting from 2
    }
    true = true_data[,t+1] # observed detrended data at 16 locations starting from time point 2
    mypath <- file.path("/home","Alaska_related",paste("multitimepoint_y",names[t], ".png", sep = ""))

    png(file=mypath)
    mytitle = paste("Predictive density of temperature at year",names[t])
    parallel.empirical.plot(x.data = t(A), plcolor = "maroon", Ncl = 8,a=-5,b=5)
    par(new=T)
    plot(true,pch='*',xlim=c(1,n),ylim=c(-5,5),xlab="",ylab=" ",axes=FALSE,col="black",cex=3,main=mytitle)
    dev.off()
}


