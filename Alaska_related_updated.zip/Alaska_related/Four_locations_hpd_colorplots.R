######## for Alaska temp data four locations time series reconstruction ####################
# Create a folder called hpd_Alaska_temp_four_locations
source("ranjanda2.R")
ff <- list.files(path="~/Fourlocations/Fourlocationsnew", full.names=TRUE)
myfilelist <- lapply(ff, read.table)
names(myfilelist) <- list.files(path="~/Fourlocations/Fourlocationsnew", full.names=FALSE)
#
true_data = read.table('~/Fourlocations/detrended_true_data.txt',na.strings = "NaN")
true_data=t(true_data)
n = dim(true_data)
#
SIZE = 65
#
names = formatC(c(25,26,28,30))
#
for(i in 1:4){
    true = t(true_data[i,2:(n[2])])
    latent_data = t(myfilelist[[i]])
#
  mypath <- file.path("/home","Alaska_related","hpd_Alaska_temp_four_locations",paste("location_y",names[i], ".png", sep = ""))
#
  png(file=mypath)
     mytitle = paste("Predictive density of temperature at L",names[i])
     parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 4,a=-5,b=5)
     par(new=T)
     plot(t(true),pch='*',xlim=c(1,SIZE),ylim=c(-5,5),xlab="",ylab=" ",axes=FALSE,col="black",cex=2,main=mytitle)
  dev.off()
#  
}
i=4
true = t(true_data[i,2:(n[2])])
latent_data = t(myfilelist[[i]])
mypath <- file.path("/home","satyaki","Alaska_related","hpd_Alaska_temp_four_locations",paste("location_y",names[i], ".png", sep = ""))
png(file=mypath)
    mytitle = paste("Predictive density of temperature at L",names[i])
    parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 4,a=-15,b=5)
    par(new=T)
    plot(t(true),pch='*',xlim=c(1,SIZE),ylim=c(-15,5),xlab="",ylab=" ",axes=FALSE,col="black",cex=2,main=mytitle)
sdev.off()
  
