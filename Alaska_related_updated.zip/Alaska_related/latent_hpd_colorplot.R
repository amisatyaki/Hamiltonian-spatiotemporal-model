source("ranjanda2.R")

########## for Alaska data ##############

# the hpd plots will save in a folder called hpd_color_plot within
# the folder Alaska_related
# So, a folder named hpd_color_plot has to be created within Alaska_related

ff <- list.files(path="~/latent_posterior", full.names=TRUE)
myfilelist <- lapply(ff, read.table)
names(myfilelist) <- list.files(path="~/latent_posterior", full.names=FALSE)



SIZE<-65


names = formatC(seq(1:26), width=2, flag="0") ## Gives a sequence of strings 1 to 30


for(i in 1:26){

  latent_data = t(myfilelist[[i]])
  true= rep(0,SIZE)	
  mypath <- file.path("/home","satyaki","Alaska_related","hpd_color_plot",paste("latent_x",names[i], ".png", sep = ""))

  png(file=mypath)
     mytitle = paste("Posterior density of latent process at L",names[i])
     parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 16,a=-5,b=5)
     par(new=T)
     plot(true,type="n",pch='*',xlim=c(1,SIZE),ylim=c(-5,5),xlab="",ylab=" ",axes=FALSE,col="black",lwd=3,main=mytitle)
  dev.off()
}
