function Omega=omega_t(y,eta3,alpha, t,m)

%s=Data{1,1};
%m=size(s);
%m=m(1);
%y=Data{1,4};
%y(:,1) = y0;
%Sigma_00 = zeros([m,m]);
%Sigma_11 = zeros([m,m]);
%Sigma_01 = zeros([m,m]);
%Sigma_10 = zeros([m,m]);
Omega=zeros([m,m]);
for i=1:m
    for j=1:m
        h0 = abs(y(i,t-1)-y(j,t-1));
        h1 = abs(y(i,t)-y(j,t));
        l01 = abs(y(i,t-1)-y(j,t));
        l10 = abs(y(i,t)-y(j,t-1));
        %Sigma_00 = 2*eta3* exp(-eta3*(h0^2))*(1-2*eta3*(h0^2));
        %Sigma_11 = 2*eta3* exp(-eta3*(h1^2))*(1-2*eta3*(h1^2)); 
        %Sigma_01 = 2*eta3* exp(-eta3*(l01^2))*(1-2*eta3*(l01^2));
        %Omega(i,j) = Sigma_00 + Sigma_11 - 2*Sigma_01;
        Sigma_00 = 2*eta3* exp(-eta3*(h0^2))*(1-2*eta3*(h0^2));
        Sigma_11 = 2*eta3* exp(-eta3*(h1^2))*(1-2*eta3*(h1^2)); 
        Sigma_01 = 2*eta3* exp(-eta3*(l01^2))*(1-2*eta3*(l01^2));
        Sigma_10 = 2*eta3* exp(-eta3*(l10^2))*(1-2*eta3*(l10^2));
        Omega(i,j) = alpha^2*Sigma_00 + alpha*Sigma_01+alpha*Sigma_10+Sigma_11;
    end
end

% if t==6
%     
%   fprintf('time = %d and max of diag of alpha2Sigma00 = %f\n', t, max(diag(alpha^2*Sigma_00)));
%   fprintf('max of diag of alphaSigma10 = %f\n', max(diag(alpha*Sigma_10)));
%   fprintf('max of diag of alphaSigma01 = %f\n', max(diag(alpha*Sigma_01)));
%   fprintf('max of diag of Sigma11 = %f\n', max(diag(Sigma_11)));
% end


%det(Omega)
%Sigma_10 = Sigma_01';

%Omega = Sigma_00 - Sigma_01 - Sigma_10 + Sigma_11;
        
