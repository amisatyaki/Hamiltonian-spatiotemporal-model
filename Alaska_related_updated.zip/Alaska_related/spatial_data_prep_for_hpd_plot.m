%
eta3 = 4.5579;
k=4;
list1 = spatial_prediction(Data,list,eta3,k)
Yfour=list1{1,1};
dim=size(Yfour);
L1 = dim(1);
n=64;
%
for l=1:L1
    Y_s1 = Yfour(l,2:n+1,:);
    Y_s1=squeeze(Y_s1);
    save (['~/Fourlocations/Y_' num2str(l) '.txt'],'Y_s1','-ascii')
end

