	1. Save the zip file named Alaska_related.
	2. Unzip the file. A folder will be created named Alaska_related. Alaska_related will have a folder Fourlocations
	 and another folder Fourlocationsnew within Fourlocations.
	 Further create three folders,  latent_posterior, hpd_Alaska_temp_four_locations and hpd_color_plot within the folder Alaska_related. 
	3. In Matlab command window load Alasakadata.mat
	4. It contains 2 elements, one is cell and another is a scaler quantity.
	5. The cell named Data is 1 x 4 cell. First one contains the locations after Lambert transformation. 
	   Second one contains a 66 x 1 matrix, ith element being i. These are time points.
	   Third contains the initial matrix for the latent variable with order 30 x 67 and 
	   4th one contains detrended temperature data of order 30 x 67. 
	   The first column of latent and the detrended variables are the initial values of x_0 and y_0. 
	6. Another two data sets, detrended observations for 16 locations for the years 2016 to 2021
		are kept in detrended_data_16locations.mat, and detrended observations
		for the 4 locations where the complete time series are predicted, are saved as detrended_true_data.txt 
		in the folder Fourlocations. 
	7. Run Bayesian_updates.m by calling list=Bayesian_updates(Data); 
	to obtain a cell named list. This will take very long time. 
	8. After getting list, run spatial_prediction.m by calling list1=spatial_prediction(Data,list,eta3,k). 
	This will create a cell named list1. This will also take a long time. 
	9. Run spatial_data_prep_for_hpd_plot.m, which will save the observations from predictive
	   densities at four spatial locations for all the times in txt format. They will be saved in
	   the folder, named Fourlocationsnew within Fourlocations. We have run the code the data are already saved in
	   Fourlocationsnew. 
       10. Run latent_posterior_storing.m, which svaes the observations from the posteriors of the latent variables in the folder latent_posterior.	   
       11. Run trace_plot.m and latent_hpd_colorplot.R to get the Figures 23 and 24 of Appendix I.1 and I.2.
       12. Run predictive_density_y_future_time.m to create Figure 25 of Appendix I.3 and then run colorplot_endtimepoint.R to get the Figure 11 of Section 7.1.2.
       13. Run multi_predict_plot.m to get Figures 26 and 27 of Appendix I.4 and then run hpd_color_plot_multi_time_predict.R to get Figure 12 of Section 7.1.2.   
       12. Run Four_locations_hpd_colotplots.R to get Figure 13. 
