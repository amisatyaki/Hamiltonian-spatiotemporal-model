function log_x0=prior_x0(x0,Omega0, sigma_p,ridge,m)

Omega0 = (sigma_p^2)*Omega0;
b=det(Omega0);
if b<1e-6
    Omega0=Omega0+ridge*eye(m);
  %  b=det(Omega0);
end
%[V1,D1] = eig(Omega0);
a= - 0.5*log(det(Omega0));
%inv_Omega0 = V1*inv(D1)*V1';
log_x0=a-0.5*(x0'/Omega0)*x0;