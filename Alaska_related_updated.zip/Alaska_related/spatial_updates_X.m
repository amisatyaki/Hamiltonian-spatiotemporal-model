function X = spatial_updates_X(Data,j,list,eta3)
% This function updates X for the purpose of spatial prediction

s= Data{1,1};
m=size(s);
m=m(1); % number of spatial points
T = Data{1,2};
n = size(T); 
n=n(1)-1; % number of time points, keep the last observation for prediction
y=Data{1,4}(:,2:n+1); % Data 

%ridge = 0.001;

%[hyperprior, list_initials] = initials(s,m);

%%%%%%%%%%%%%%%%%%%%%% initials %%%%%%%%%%%%%%%%%%

beta_old = list{1,1}(j);
alpha_old =list{1,2}(j);
sigma_old = list{1,5}(j);
%sigma_theta_old = list{1,3}(j);
sigma_p_old = list{1,4}(j);
%x0_old = squeeze(list{1,9}(:,1,25000));
y0_old = Data{1,4}(:,1);



%eta1=list{1,6};
%eta2=list{1,7};

X = list{1,9}(:,1:n+1,max(1,j-1));%zeros([m,n+1]); %%
%X(:,1) = x0_old;

y = [y0_old,y]; 
N= 1;
%M= 0;
[M_s,D] = Ms(s,m);


%%%%%%%%%%%%%% lets start MCMC %%%%%%%%%%%%%%%%%%
eta1_old = list{1,6}(j);
%eta2_old = list{1,6}(j);
eta3_old = eta3;

    Omega0 = delta_omega0(eta1_old,s,m);
    Sigma0 = Sigma_data_j(eta3_old, 1, M_s, y,m);
    Omega1 = omega_t(y,eta3_old,alpha_old, 2,m);
    
for i=1:N
    
    
    [A,B,C] = matrix_A_B_C(D,Sigma0, Omega0,Omega1,alpha_old, m, sigma_old,... 
       sigma_p_old,0.01);
    x0_old = x_0(A,B,C,X(:,2),y, beta_old,sigma_p_old,0.000001,m);
    X(:,1) = x0_old;
    for t=2:n+1
       Omega = omega_t(y,eta3_old,alpha_old,t,m);
       X(:,t) = x_t(X,m,alpha_old, Omega, sigma_old,t,0.0000001);
    end

%    list = {beta_final,alpha_final, sigma_theta_final,sigma_p_final,sigma_final, eta1_final,...
%         eta2_final, eta3_final, X_final,y0_final,y_predict,x_predict};
end

