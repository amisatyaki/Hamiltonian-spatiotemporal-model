function S=sigma_mat(s,sigma,lambda)
m=size(s);
m=m(1);
S=zeros([m,m]);
for i=1:m
    for j=1:m
        k=-lambda*norm(s(i,:)-s(j,:));
        S(i,j) = sigma^2*exp(k);
    end
end