function [M_s,D] = Ms(s,m)

%s=Data{1,1};

%m=size(s);
%m=m(1);
mx=zeros([m,1]);
for i=1:m
    for j=1:m
        mx(i) = max(0.25*norm(s(i,:).^2 - s(j,:).^2)^2,mx(i)); % for sea temp data
        %mx(i) = max(norm(s(i,:).^2 - s(j,:).^2)^2,mx(i)); %
    end
end


M_s=exp(mx); 
D=diag(M_s);


