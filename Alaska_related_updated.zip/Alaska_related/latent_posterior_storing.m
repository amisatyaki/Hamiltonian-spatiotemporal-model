% This prepares and stores the data for posterior latent 
% densities plots in the folder named latent_posterior
% so first create a folder named with latent_posterior.
% hpd plots are made in R, written in a different file
%
s= Data{1,1};
m=size(s);
m=m(1) - 10; % number of spatial points
T = Data{1,2};
n = size(T); 
n=n(1)-1;
X=list{1,9};
#
for k=1:m
    X_s1 = X(k,2:n+1,:);
    X_s1=squeeze(X_s1);
    save (['/latent_posterior/X_' num2str(k) '.txt'],'X_s1','-ascii')
end
