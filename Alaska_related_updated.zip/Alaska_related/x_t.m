function xt=x_t(x,m,alpha, Omega,sigma,t,ridge)
%ridge=ridge+t/200;
%ridge=(ridge/4)*(t~=12)+(ridge/2000)*(t==12)
%ridge=ridge+1;
%x=Data{1,3}; 

%s=Data{1,1};
%m=size(s);
%m=m(1);
%alpha=0.001*x(:,t-1);
%Omega = omega_t(Data,eta3,t);
%ridge=ridge-ridge;
Omega = (sigma^2/4).*Omega;
b=det(Omega);
if b<1e-6
    Omega=Omega+ridge*eye(m);
  %  b=det(Omega);
end
% if b>1e+20
%     Omega = Omega - (4/5)*ridge*eye(m);
% end
%  b = det(Omega)
mu = (alpha^2)*x(:,t-1);

%  fprintf('time = %d, det of omega_t = %f, max of diag of omega_t = %f\n', t, det(Omega), max(diag(Omega)));

xt=mvnrnd(mu,Omega)';


