function [y0_old] = update_y0_rw(y,alpha, eta2, eta3, sigma, X,M_s,D, sigma_theta,beta, ...
   s,m,ridge)

y0_old = y(:,1);

Delta0 = delta_omega0(eta2,s,m);

mu1=alpha*inv(D)*X(:,1);

log_y0 = prior_y0(Delta0,sigma_theta,y0_old,m,ridge);

mu=beta*y0_old+mu1;
S=(sigma^2/4)*Sigma_data_j(eta3, 1, M_s, y,m);    
if det(S)<1e-6
   S=S+ridge*eye(m);
end
a=-m*log(sqrt(2*pi)) - 0.5*log(det(S));
log_y1=a-0.5*((y(:,2)-mu)'/S)*(y(:,2)-mu);


Omega = (sigma^2/4)*omega_t(y, eta3, alpha,2,m);
if det(Omega)<1e-6
   Omega = Omega + ridge*eye(m);
end

a= -m*log(sqrt(2*pi)) - 0.5*log(det(Omega));

log_x1=a-0.5*((X(:,2)-alpha^2*X(:,1))'/Omega)*(X(:,2)-alpha^2*X(:,1));
    

log_denom = log_y0 + log_y1 + log_x1;

epsilon = normrnd(0,10,[m,1]);
y0_tilde = y0_old + epsilon;

y(:,1) = y0_tilde;

log_y0 = prior_y0(Delta0,sigma_theta,y0_tilde,m,ridge);

mu=beta*y0_tilde+mu1;
S=(sigma^2/4)*Sigma_data_j(eta3, 1, M_s, y,m);    
    if det(S)<1e-6
        S=S+ridge*eye(m);
    end
    a=-m*log(sqrt(2*pi)) - 0.5*log(det(S));
    log_y1=a-0.5*((y(:,2)-mu)'/S)*(y(:,2)-mu);

Omega = (sigma^2/4)*omega_t(y, eta3,alpha, 2,m);
    if det(Omega)<1e-6
        Omega = Omega + ridge*eye(m);
    end

    a= -m*log(sqrt(2*pi)) - 0.5*log(det(Omega));

    log_x1=a-0.5*((X(:,2)-alpha^2*X(:,1))'/Omega)*(X(:,2)-alpha^2*X(:,1));
    log_num = log_y0 + log_y1 + log_x1;
    
    log_diff = log_num - log_denom;
    pi1 = exp(log_diff);
    if (unifrnd(0,1)<=pi1)
        y0_old = y0_tilde;
    end