function delta=delta_omega0(eta,s,m)
% This function calculates either Omega0 or Delta0. If we are calculating
% Delta0 then use eta2 otherwise use eta1. 
%s=Data{1,1};
%m=size(s);
%m=m(1);
delta=zeros([m,m]);
for i=1:m
    for j=1:m
        k=-eta*(norm(s(i,:)-s(j,:)))^2;
        delta(i,j) = exp(k);
    end
end
%sort(eig(delta),'descend')
% [V,d] = eig(delta);
% [d,ind]=sort(diag(d),'descend');
% V=V(:,ind);
% a=cumsum(d/sum(d));
% k=find(a>0.85,1);
% V=V(:,1:k);
% delta = V*diag(d(1:k))*V';
% delta_inv = V*inv(diag(d(1:k)))*V'