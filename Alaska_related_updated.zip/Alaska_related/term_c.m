function [c1,c2]=term_c(eta3,M_s,y,sigma,ridge,m,T)
%y=Data{1,4};
%y(:,1) = y0;
% T=Data{1,2};
% T=length(T);
% s=Data{1,1};
% m=size(s);
% m=m(1);
%ridge=ridge;
c1=0; c2=0;
for j=1:T
    S=Sigma_data_j(eta3, j, M_s, y,m);
    a=det(S);
%     eig(S)
    while (a<1e-6)
        S= S+ ridge*eye(m);
        a= det(S);
    end
%      [V,D] = eig(S);
%     inv_S = V*inv(D)*V';
    c1=c1+(y(:,j)'/S)*y(:,j);
    c2 = c2+ (y(:,j)'/S)*y(:,(j+1));
end
c1=(2/sigma^2)*c1;
c2 = (4/sigma^2)*c2;
