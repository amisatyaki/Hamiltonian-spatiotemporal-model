function log_y0=prior_y0(Delta0,sigma_theta,y0,m,ridge)

Delta0 = sigma_theta^2*Delta0;
b=det(Delta0);

if b<1e-6
    Delta0 = Delta0+ridge*eye(m);
    %b=det(Delta0);
end

log_y0 = - (1/2)*log(det(Delta0)) - (1/2)*(y0'/Delta0)*y0;
    
