source("ranjanda2.R")
#
true_data = read.table('true_y_end.txt',na.strings = "NaN")

SIZE<-26 # number of locations for Alaska data
predicted_data = read.table("predicted_y_endpoint.txt")

predicted_data1 = t(predicted_data[1:SIZE,])


true = (true_data[1:SIZE,])

png(file="endtimepoint_predicted.png")
parallel.empirical.plot(x.data = predicted_data1, plcolor = "maroon", Ncl = 4,a=-3.25,b=5.15)
par(new=T)
plot(true,pch='*',xlim=c(1,SIZE),ylim=c(-3.25,5.15),xlab="",ylab=" ",axes=FALSE,col="black",cex=3,main="Predictive densities for 26 locations")
dev.off()
