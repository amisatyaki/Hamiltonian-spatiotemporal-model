s= Data{1,1};
m=size(s);
m=m(1); % number of spatial points
T = Data{1,2};
n = size(T); 
n=n(1)-1;
%[M_s,D] = Ms(s,m);



X=list{1,9};


%Xorg=Data{1,3};

%save(['/home/satyaki/Desktop/Sourabh Sir/Code/NLDSTM/latent_posterior/true_latent.txt'],'Xorg','-ascii')

for k=1:m
    X_s1 = X(k,2:n+1,:);
    X_s1=squeeze(X_s1);
    save (['/home/satyaki/Desktop/Sourabh Sir/real_data/Sea_temp_data/latent/X_' num2str(k) '.txt'],'X_s1','-ascii')
end

% for k=1:m
%     X_s1 = X(k,2:n+1,:);
%     X_s1=squeeze(X_s1);
% 
% %     L=zeros([n,1]);
% %     U=zeros([n,1]);
% %     M=zeros([n,1]);
%     L = quantile(X_s1',0.025);
%     U = quantile(X_s1',0.975);
%     M = mean(X_s1');
% %     for i=1:n
% %         L(i) = quantile(X_s1(i,:),0.025);
% %         U(i) = quantile(X_s1(i,:),0.975);
% %         M(i) = mean(X_s1(i,:));%quantile(X_s1(i,:),0.5);
% %     end
%  Xorg_s1 = Xorg(k,:);
% 
% if (k<=25)
%     figure(1011)
%     subplot(5,5,k), plot(L); hold on;
%     plot(M); plot(U); plot(Xorg_s1(2:end-1));
%     hold off;
% 
% end
% if (k>25)
%     figure(1012)
%     subplot(5,5,k-25), plot(L); hold on;
%     plot(M); plot(U); plot(Xorg_s1(2:end-1));
%     hold off;
% 
% end
%     figure(k)
%        plot(L)
%     hold on
%     plot(M)
%     plot(U)
%     plot(Xorg_s1(2:end-1))
%     hold off
% end

% for l=1:n
% 
%     Xorg_1 = Xorg(:,l+1);
% 
%     X_1 = squeeze(X(:,l+1,:));
%     L=zeros([m,1]);
%     U=zeros([m,1]);
%     M=zeros([m,1]);
%     for j=1:m
%         L(j) = quantile(X_1(j,:),0.025);
%         U(j) = quantile(X_1(j,:),0.975);
%         M(j) = quantile(X_1(j,:),0.5);
%     end
%     figure(l+m)
%     plot(L)
%     hold on
%     plot(M)
%     plot(U)
%     plot(Xorg_1)
%     hold off
% end



% y0_org = Data{1,4}(:,1);
% y0=list{1,10};
% L=zeros([m,1]);
% U=zeros([m,1]);
% for j=1:m
%     L(j) = quantile(y0(j,:),0.025);
%     U(j) = quantile(y0(j,:),0.975);
% end
% figure(102)
% plot(L)
% hold on
% plot(U)
% plot(y0_org)
% hold off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

beta=list{1,1};
alpha=list{1,2};
sigma_theta=list{1,3};
sigma_p=list{1,4};
sigma=list{1,5};
eta1=list{1,6};
eta2=list{1,7};
%eta3=list{1,8};

figure(1)
subplot(2,4,1), plot(beta); hold on 
% plot([0,25000],[true_param{1,2},true_param{1,2}],'r--');
% xlim([0,25000])
t='Trace plot of $\beta$';
title (t,'interpreter','latex')
hold off
subplot(2,4,2), plot(alpha); hold on 
% plot([0,25000],[true_param{1,1},true_param{1,1}],'r--'); 
% xlim([0,25000])
t='Trace plot of $\alpha$';
title (t,'interpreter','latex')
hold off
subplot(2,4,3), plot(sigma_theta); hold on 
% plot([0,25000],[true_param{1,6},true_param{1,6}],'r--'); 
% xlim([0,25000])
t='Trace plot of $\sigma_{\theta}$';
title (t,'interpreter','latex')
hold off
subplot(2,4,4), plot(sigma_p); hold on 
% plot([0,25000],[true_param{1,7},true_param{1,7}],'r--'); 
% xlim([0,25000])
t='Trace plot of $\sigma_{p}$';
title (t,'interpreter','latex')
hold off
subplot(2,4,5), plot(sigma); hold on
% plot([0,25000],[true_param{1,8},true_param{1,8}],'r--'); 
% xlim([0,25000])
t='Trace plot of $\sigma$';
title (t,'interpreter','latex')
hold off
subplot(2,4,6), plot(eta1); hold on
% plot([0,25000],[true_param{1,3},true_param{1,3}],'r--'); 
% xlim([0,25000])
t='Trace plot of $\eta_1$';
title (t,'interpreter','latex')
hold off
subplot(2,4,7), plot(eta2); hold on
% plot([0,25000],[true_param{1,4},true_param{1,4}],'r--'); 
% xlim([0,25000])
t='Trace plot of $\eta_2$';
title (t,'interpreter','latex')
hold off
% subplot(2,4,8), plot(eta3); hold on
% plot([0,25000],[true_param{1,5},true_param{1,5}],'r--'); 
% xlim([0,25000])
% t='Trace plot of $\eta_3$';
% title (t,'interpreter','latex')
% hold off

% figure(2)
% subplot(2,4,1), hist(beta); hold on 
% plot([true_param{1,2},true_param{1,2}],[0,10000],'r--');
% t='Histogram of $\beta$';
% title (t,'interpreter','latex')
% hold off
% subplot(2,4,2), hist(alpha); hold on 
% plot([true_param{1,1},true_param{1,1}],[0,10000],'r--'); 
% t='Histogram of $\alpha$';
% title (t,'interpreter','latex')
% hold off
% subplot(2,4,3), hist(sigma_theta); hold on 
% plot([true_param{1,6},true_param{1,6}],[0,10000],'r--'); 
% t='Histogram of $\sigma_{\theta}$';
% title (t,'interpreter','latex')
% hold off
% subplot(2,4,4), hist(sigma_p); hold on 
% plot([true_param{1,7},true_param{1,7}],[0,10000],'r--'); 
% t='Histogram of $\sigma_{p}$';
% title (t,'interpreter','latex')
% hold off
% subplot(2,4,5), hist(sigma); hold on
% plot([true_param{1,8},true_param{1,8}],[0,10000],'r--'); 
% t='Histogram $\sigma$';
% title (t,'interpreter','latex')
% hold off
% subplot(2,4,6), hist(eta1); hold on
% plot([true_param{1,3},true_param{1,3}],[0,10000],'r--'); 
% t='Histogram of $\eta_1$';
% title (t,'interpreter','latex')
% hold off
% subplot(2,4,7), hist(eta2); hold on
% plot([true_param{1,4},true_param{1,4}],[0,10000],'r--'); 
% t='Histogram of $\eta_2$';
% title (t,'interpreter','latex')
% hold off
% subplot(2,4,8), hist(eta3); hold on
% plot([true_param{1,5},true_param{1,5}],[0,10000],'r--'); 
% t='Histogram of $\eta_3$';
% title (t,'interpreter','latex')
% hold off


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y_predict = list{1,11};
y_obsd = Data{1,4}(:,end);

figure(1)
% for k=1:5
%     subplot(1,5,k), hist(y_predict(k,:)); hold on
%     L = quantile(y_predict(k,:),0.025);
%     U=quantile(y_predict(k,:),0.975);
%     plot([L,U],[0,0],'r','LineWidth',3)
%     plot([y_obsd(k),y_obsd(k)],[0,10000],'k','LineWidth',2)
%     hold off
% end
for k=1:30
    subplot(6,5,k), [f,x] = ksdensity(y_predict(k,:)); plot(x,f);
    ylim([0, max(f)])
    %hist(y_predict(k,:)); 
    hold on
    L = quantile(y_predict(k,:),0.025);
    U=quantile(y_predict(k,:),0.975);
    plot([L,U],[0,0],'r','LineWidth',3)
    if k<31
        plot([y_obsd(k),y_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
    end
%     if k==27
%         plot([y_obsd(k),y_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
%     end
%     if k==29
%         plot([y_obsd(k),y_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
%     end
    hold off
    
end
% figure(2)
% for k=26:50
%     subplot(5,5,k-25), [f,x] = ksdensity(y_predict(k,:)); plot(x,f);
%     ylim([0, max(f)])
%     %hist(y_predict(k,:)); 
%     hold on
%     L = quantile(y_predict(k,:),0.025);
%     U=quantile(y_predict(k,:),0.975);
%     plot([L,U],[0,0],'r','LineWidth',3)
%     plot([y_obsd(k),y_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
%     hold off
%     
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
% x_predict= zeros(m,25000);
% addpath('/home/satyaki/Desktop/Sourabh Sir/Code')
% y=Data{1,4};
% 
% for j=1:25000
%     w=[y,y_predict(:,j)];
%     Omega = omega_t(w,eta3,alpha(j), n+2,m);
%         A = (sigma(j)^2/4).*Omega;
%         x_predict(:,j) = mvnrnd(alpha(j)^2*X(:,n+1,j),A);
%     
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x_predict = list{1,12};

x_obsd = Data{1,3}(:,end);

figure(1)
% for k=1:5
%     subplot(1,5,k), hist(y_predict(k,:)); hold on
%     L = quantile(y_predict(k,:),0.025);
%     U=quantile(y_predict(k,:),0.975);
%     plot([L,U],[0,0],'r','LineWidth',3)
%     plot([y_obsd(k),y_obsd(k)],[0,10000],'k','LineWidth',2)
%     hold off
% end
for k=1:30
    subplot(6,5,k), [f,x] = ksdensity(x_predict(k,:)); plot(x,f);
    ylim([0, max(f)+0.001])
    %hist(y_predict(k,:)); 
%     hold on
%     L = quantile(x_predict(k,:),0.025);
%     U=quantile(x_predict(k,:),0.975);
%     plot([L,U],[0,0],'r','LineWidth',3)
%     plot([x_obsd(k),x_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
%     hold off
    
end
% figure(2)
% for k=26:50
%     subplot(5,5,k-25), [f,x] = ksdensity(x_predict(k,:)); plot(x,f);
%     ylim([0, max(f)+0.001])
%     %hist(y_predict(k,:)); 
%     hold on
%     L = quantile(x_predict(k,:),0.025);
%     U=quantile(x_predict(k,:),0.975);
%     plot([L,U],[0,0],'r','LineWidth',3)
%     plot([x_obsd(k),x_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
%     hold off
%     
% end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% multiple time point prediction for
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Indian temp data %%%%%%%%%%%%%%%%
% y_multi_predict = multi_predict(Data,list,eta3);
% 
% % for k=1:m
% %     X_s1 = y_multi_predict(k,:,:);
% %     X_s1=squeeze(X_s1);
% %     save (['/home/satyaki/Desktop/Sourabh Sir/real_data/Indian_subcontinent_data/multi_predict/ypredict_' num2str(k) '.txt'],'X_s1','-ascii')
% % end
% 
% 
% y={squeeze(y_multi_predict(1,:,:)),squeeze(y_multi_predict(7,:,:)),squeeze(y_multi_predict(9,:,:)),squeeze(y_multi_predict(15,:,:))};
% 
% for k=1:4
%     for l=1:3
%         subplot(4,3,k*l+(k-1)*(3-l)), [f,x] = ksdensity(y{1,k}(l+1,:)); plot(x,f);
%         ylim([0, max(f)])
%         hold on 
%         L = quantile(y{1,k}(l+1,:),0.025);
%         U=quantile(y{1,k}(l+1,:),0.975);
%         plot([L,U],[0,0],'r','LineWidth',3)
%         plot([ymulttrue(k,l+1),ymulttrue(k,l+1)],[0,max(ylim)],'k','LineWidth',2)
% %         t='';
% %         title (t,'interpreter','latex')
%         hold off
%     end
% end


%%%%%%%%%%%%% detrending the USA data %%%%%%%%%%%%%%%%

data2=zeros(66,30);
trend=zeros(66,30);
for i=1:30
detrendeddata = detrend(data1(:,i));
data2(:,i) = detrendeddata;
trend(:,i) = data1(:,i)-detrendeddata;
end

%%%%%%%%%%%%%%% converting the locations by Lambert transformation %%%%%

s=table2array(USAlocations);

s=deg2rad(s);
s1=s(:,1);
s(:,1)=s(:,2);
s(:,2)=s1;
s1=2*sin(pi/4-s(:,2)/2).*sin(s(:,1));
s2=-2*sin(pi/4-s(:,2)/2).*cos(s(:,1));
s=[s1,s2];
Data{1,1}=s;
clear USAlocations s s1 s2 


%%%%%%%%%%%%%%% plot of predicted time series of last four locations for Alaska data %%%%%%%

% L1=4;
% a=table2array(Fourlocationsdata);
% for k=1:L1
%     Y_s = list1{1,1}(k,2:n+1,:);
%     Y_s=squeeze(Y_s);
% 
%     L = quantile(Y_s',0.025);
%     U = quantile(Y_s',0.975);
%     b=data2(m-L1+k,2:66);
%     c=find(isnan(a(:,k)));
%     b(c)=NaN;
%     figure(101)
%     subplot(1,4,k), plot(L); hold on;
%     %plot(a(:,k),'*');
%     plot(b,'*');
%     plot(U); 
%     hold off;
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Run the code list = Bayesian_updates(Data) to get the posteriors on 
% Alaska data. Second and third component of Data should be filled with
% T and initial latent matrix X

% Then run the code list1 = spatial_prediction(Data,list,eta3,k) for finding
% the posteriors for the complete time series at the k locations
Yfour=list1{1,1};


%Xorg=Data{1,3};

%save(['/home/satyaki/Desktop/Sourabh Sir/Code/NLDSTM/latent_posterior/true_latent.txt'],'Xorg','-ascii')

for k=1:L1
    Y_s1 = Yfour(k,2:n+1,:);
    Y_s1=squeeze(Y_s1);
    save (['/home/satyaki/Desktop/Sourabh Sir/real_data/Alaska/Fourlocations/Y_' num2str(k) '.txt'],'Y_s1','-ascii')
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% multiple time point prediction for
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Alaska temp data %%%%%%%%%%%%%%%%
y_multi_predict = multi_predict(Data,list,eta3);


for i=1:7
    y{1,i} = squeeze(y_multi_predict(i,:,:));
end


for i=1:3
    y{1,7+i} = squeeze(y_multi_predict(10+i,:,:));
end

for i=1:3
    y{1,10+i} = squeeze(y_multi_predict(17+i,:,:));
end

y{1,14} = squeeze(y_multi_predict(22,:,:));
y{1,15} = squeeze(y_multi_predict(27,:,:));
y{1,16} = squeeze(y_multi_predict(29,:,:));

ymulttrue=[data(:,1:7),data(:,11:13),data(:,18:20),data(:,22),data(:,27),data(:,29)];

ymulttrue(42,2) = mean(ymulttrue(37:41,2));
ymulttrue(44,2) = mean(ymulttrue(39:43,2));
ymulttrue(47,15) = mean(ymulttrue(42:46,15));
ymulttrue(48,15) = mean(ymulttrue(43:47,15));


for i=1:16
detrendeddata = detrend(ymulttrue(:,i));
ymulttrue(:,i) = detrendeddata;
%trend(:,i) = data1(:,i)-detrendeddata;
end
ymulttrue = ymulttrue(66:end,:)';


figure(103)
for k=1:8
    for l=1:6
        subplot(8,6,k*l+(k-1)*(6-l)), [f,x] = ksdensity(y{1,k}(l+1,:)); plot(x,f);
        ylim([0, max(f)])
        hold on 
        L = quantile(y{1,k}(l+1,:),0.025);
        U=quantile(y{1,k}(l+1,:),0.975);
        plot([L,U],[0,0],'r','LineWidth',3)
        plot([ymulttrue(k,l+1),ymulttrue(k,l+1)],[0,max(ylim)],'k','LineWidth',2)
%         t='';
%         title (t,'interpreter','latex')
        hold off
    end
end

figure(105)
for k=1:8
    for l=1:6
        subplot(8,6,k*l+(k-1)*(6-l)), [f,x] = ksdensity(y{1,8+k}(l+1,:)); plot(x,f);
        ylim([0, max(f)])
        hold on 
        L = quantile(y{1,8+k}(l+1,:),0.025);
        U=quantile(y{1,8+k}(l+1,:),0.975);
        plot([L,U],[0,0],'r','LineWidth',3)
        plot([ymulttrue(8+k,l+1),ymulttrue(8+k,l+1)],[0,max(ylim)],'k','LineWidth',2)
%         t='';
%         title (t,'interpreter','latex')
        hold off
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% %%%%% spatial prediction for sea temperature data %%%%
%%% this is for the reconstruction of the complete times series at the 20
%%% locations  
%%% the data are saved in txt format for r code to be run (coloured hpd plot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Ytwenty=list1{1,1}; % the predictive posterior data for two locations
dim = size(Ytwenty);
L1=dim(1); % number of locations at which the complete time series are reconstructed
n= dim(2); % number of time points

for k=1:L1
    Y_s1 = Ytwenty(k,1:n,:); % predictive data for location k, time=2:101, all the iterated values
    Y_s1=squeeze(Y_s1); % this made the data two dimensional by squeezing the 1 dimension
    save (['/home/satyaki/Desktop/Sourabh Sir/real_data/Sea_temp_data/twenty locations/Y_' num2str(k) '.txt'],'Y_s1','-ascii')
end

%y_true = true
save (['/home/satyaki/Desktop/Sourabh Sir/real_data/Sea_temp_data/twenty locations/true_data' '.txt'],'true_data','-ascii')

%clear

% Plotting of locations for the sea surface temperature data %%%%%

plot(s(1:30,1),s(1:30,2),'.r','MarkerSize',15)
hold on
plot(s(31:35,1),s(31:35,2),'.b','MarkerSize',15)
plot(s(36,1),s(36,2),'*k','MarkerSize',8)
plot(s(37:38,1),s(37:38,2),'.b','MarkerSize',15)
plot(s(39,1),s(39,2),'*g','MarkerSize',8)
xlabel('s_1')
ylabel('s_2')
t='Location of sea surface temperature after transformation';
title (t,'interpreter','latex')
hold off

