function zeta = term_zeta(y,X,M_s,D,alpha,beta,eta3,m,T,ridge)
zeta=0;
%ridge=ridge;
for j=1:T
    mu=beta*y(:,j)+alpha*inv(D)*X(:,j);
    S=Sigma_data_j(eta3, j, M_s, y,m);
    
    a=det(S);
    if a<1e-6
        S=S+ridge*eye(m);
      %  a=det(S);
    end
    %[V1,D1] = eig(S);
    %inv_S= V1*inv(D1)*V1';
    
    z=((y(:,j+1)-mu)'/S)*(y(:,j+1)-mu);
    
    %alpha = X(:,j);
    Omega = omega_t(y, eta3, alpha, j+1,m);
    b=det(Omega);
    if b<1e-6
        Omega = Omega+ridge*eye(m);
        %a=det(Omega);
    end
    zeta = zeta+z+((X(:,j+1)-alpha^2*X(:,j))'/Omega)*(X(:,j+1)-alpha^2*X(:,j));
    
    %log_d1 = log_d1+a;
    %log_d1 = log_d1+log(mvnpdf(y(:,j+1),mu,S));
end