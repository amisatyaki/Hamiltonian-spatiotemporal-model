The codes are developed majorly in matlab. However, some graphical representations
are done in R software as well. 

The functions can be divided into two phases. In the first phase, the parameters
are updated using MCMC runs. The second phase of codes are mainly used for 
data arrangements, detrending and depiction purpose. 

There are total 19 functions, mentioned below, used for the first phase.
0. simulated_annealing_eta3.m
1. Bayesian_updates.m
2. initials.m 
3. term_c.m
4. update_beta_TMCMC.m
5. update_alpha_rw.m
6. delta_omega0.m
7. fcd_sigma_theta.m
8. fcd_sigma_p.m
9. Sigma_data_j.m
10. omega_t.m
11. matrix_A_B_C.m
12. x_0.m
13. x_t.m
14. term_zeta.m
15. fcd_sigma.m
16. update_eta1_rw.m
17. update_eta2_rw.m
18. Ms.m

Notation
--------
m = number of locations
n = number of time points
y= [y0 : observed data matrix of order m x n]
T = time points from 1 to n
s= location matrix of order m x 2
X = latent matrix of order m x (n+1)
alpha_theta, gamma_theta = hyperparameters of sigma_theta
y0=the value of y at time point 0 (supplied by the user)
ridge= a ridge parameter to make the matrices invertible
alpha_p, gamma_p = hyperparameters of sigma_p
alpha_v, gamma_v = hyperparameters of sigma

Description:
-----------
-----------

simulated_annealing_eta3.m
--------------------------
It produces MLE of eta3 using simulated annealing technique. 
It takes a cell called Data as its input. 
The first component of Data contains the locations, s, which is a m x 2 matrix, where
m is the number of spatial points. Second component of cell contains the time points, T, 
which is a sequence from 1 to n, where n is the total number of time points. 
The third component of cell contains the initial value of the latent matrix, denoted by X,
which is of order m x (n+1). The first column is introduced for the intial
value of x at time point 0 at every location. This column corresponds to
x_0 in the paper. 
The final cell of Data contains the observed data which is of order m x (n+1).
The first column stands for a value of y_0 (according to notation of the paper), 
which has to be supplied by the user and is kept fixed for complete MCMC run. 

Bayesian_update.m
------------------
Bayesian_update.m updates all the parameters and the latent variables 
present in the model. Also this gives the predictive densities
at every location at future time points. The outputs are stored in a cell. 

The function takes a single input, namely Data, which is a cell and description of 
the components are given while describing simulated_annealing_eta3.m. 

Bayesian_update.m uses the other functions 2 to 18, as listed above. The descriptions
are as follows. 

initials.m
----------
This function fixes the initial values and the values of hyperpriors
used in the proposed model of the paper. 

It takes the location information s as a m x 2 matrix and the number of locations m. 
The outputs are stored in two cells, the first one contains the values of
hyperpriors and the second stores the initial values of the parameters. 

term_c.m
------
This function calculates the two terms, named as c1,c2,
which are present in the exponent of the g_1(beta^*) excluding beta of 
the equation (10) in the paper. It takes the value of eta3, M_s (which is produced
by the function Ms.m, described later), y, value
of the parameter sigma, a ridge parameter, m and T. 

The output is stored as a vector of length two. 

update_beta_TMCMC.m
-------------------
This function updates the betastar parameter using random walk MCMC. 
It takes the value of sigma_beta, the i-th iteration value of betastar, the 
values c1 and c2 produced by the function term.c

The output is stored as a scalar quantity. 

update_alpha_rw.m
-----------------
This function updates the alphastar parameter using the random walk MCMC. 
It takes sigma_alpha, i-th iterated value of alphastar,
M_s & D (which are produced by the function Ms.m),
X (i-th iterated latent matrix), y, the value of eta3,
i-th iterated value of sigma,
m, T and a ridge value. 

The output is stored as a scalar. 

delta_omega0.m
--------------
This function calculates either Omega0 or Delta0, which are the var-cov 
matrices of theta_s(0) and p_s(0) of the paper (see paragraph after equation (8)
of the paper). It takes the input eta, s and m. Depending on whether the input
is iterated value of eta1 or eta2 the function returns Omega0 or Delta0. 

fcd_sigma_theta.m
-----------------
It simulates a scalar from the full conditional density of sigma_theta (see Section 5 for the 
full conditional of sigma_theta). 

It takes alpha_theta, gamma_theta, Delta0 (produced by delta_omega0.m with eta2),m,y0,ridge


fcd_sigma_p.m
-------------
It simulates a scalar from the full conditional density of sigma_p (see Section 5 for the 
full conditional of sigma_p). 

It takes inputs as alpha_p, gamma_p, x_0,Omega0 (produced by delta_omega0.m with eta1),m and ridge.


Sigma_data_j.m
--------------
It calculates the matrix Sigma_{j-1} of the paper (see description after equation (6)).
It takes the value of eta3, j in {1, ...,n+1}, M_s (produced by the function Ms.m), y and m
as the inputs.  

omega_t.m
---------
It calculates the matrix Omega_t of paper (defined after the equation (7)). 
It takes y, the value of eta3,
i-th iterated value of alpha, t a number in {2, ..., n+1} and m as inputs. 


matrix_A_B_C.m
--------------
It returns the matrices A, B and C of the paper, which are described while providing
full conditional density of x_0 (see Section 5 of the paper).
It takes D (produced by Ms.m),Sigma0 (produced by Sigma_data_j.m), 
Omega0(produced by delta_omega0.m with eta1),Omega1(produced by omega_t.m),
i-th iterative value of alpha, m, i-th iterative value of sigma,
i-th iterative value of sigma_p and a ridge value. 

x_0.m
-----
It updates the latent variable x0 from its full conditional (see Section 5 of the paper).
It produces a vector of length m. 
It takes A,B,C, (produced by matrix_A_B_C.m)
x1 (the values of latent variable at time point 1),
y, i-th iterative value of beta,
i-th iterative value of sigma_p, ridge and m as input.


x_t.m
-----
It updates x_t using its full conditional (see Section 5 of the paper) for time points 1, 2, ...n. 
It produces a m x 1 order matrix. 
It takes X,m,i-th iterative value of alpha, Omega (matrix produced from omega_t,m),
i-th iterative value of sigma,t a number in {2, ..., n+1} and ridge. 


term_zeta.m
-----------
It calculates the value of zeta which is used to update the parameter sigma (See Section 5 of the paper). 
It produces a scalar value. 
It takes y,X,M_s,D (produced by Ms.m), i-th iterative value of alpha, 
i-th iterative value of beta,the value of eta3, m, T and ridge as input. 


fcd_sigma.m
-----------
It simulates a scalar from the full conditional density of sigma (see Section 5 for the 
full conditional of sigma).  
It takes alpha_v, gamma_v, zeta (produced by term_zeta.m), m and T as input. 

update_eta1_rw.m
----------------
It updates eta1star using random walk MCMC using the full conditional of eta1star (see Section 5 for the 
full conditional of eta1star). 
It takes  X,i-th iterative value of eta1star sigma_p,i-th iterative value of eta1star, s,m and ridge
as input. 

update_eta2_rw.m
----------------
It updates eta2star using random walk MCMC using the full conditional of eta2star (see Section 5 for the 
full conditional of eta2star). 
It takes y, i-th iterative value of sigma_theta, i-th iterative value of eta2star,s,m and ridge
as input variables. 

Ms.m
----
It produces M_s (see definition 5 of the paper)
and the diagonal matrix D with the diagonal entries being the values of M_s.
It takes s and m as the input of the function. 

-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
In the second phase, from the output of Bayesian_updates.m, which is stored in list as cell,
the multiple time point predictions and predictions at unknown locations are made. Also, the relevant
posterior samples are extracted and different plots are produced. 

spatial_prediction.m
--------------------
This function produces the posterior densities for the complete time series at the k locations out of m locations. 
It serves as the spatial prediction. 
It takes Data,list (output of Bayesian_updates.m),eta3 (simmulated annealing value of eta3), k (the number of
locations at which predictions have to be made) as inputs.

The ouput stores in a cell, named as list1.

multi_predict.m
---------------
It produces the multiple time point future prediction at every location depending on the 
MCMC samples of the parameters. 
It takes Data,(output of Bayesian_updates.m),eta3 (simmulated annealing value of eta3), as
the input variables. 
The output is stored as a 3-dimensional matrix, where the first dimension is
for the time points, second one is for location and third one is for simulations.  

misc.m
----------
The first 6 lines of this function extracts the s, m, T and n from cell Data. 

Line number 11 extracts the posterior samples from the output of Bayesian_updates.m. 
The line numbers 18 to 22, extracts the complete MCMC runs for each of m latent variables and stored them
separately as .txt file in the working directory. These are used to produce the colored hpd plots using 
software R. The description of the function in R will be given later. 

Next the lines 104 to 155 extracts the simulated values from the posteriors of the parameters
other than eta3 and plot the respective trace plots. 

The lines 207 to 238 extracts the posterior predictive samples for the observed data for 
future time point at every location and plot the corresponding density functions along 
with the credible intervals as horizontal red line and a verticle black line to indicate the true values. 

The lines 267 to 291 extracts the posterior predictive samples for the latent variable 
for future time point at every location and plot the corresponding density functions 
(along with the credible intervals as horizontal red line and a verticle black line to indicate the true 
values only for the simulated data sets, when user know the truth, appropriate lines, which are self explanatory
have to be uncommented).

----------------------------------------
Next an outline of the example is given.
----------------------------------------
Lines 338 to 344 detrended the Alaska temperature data and lines 348 to 358 convert the latitude longitude
using Lambert's projection for Alaska temperature data and store it as the first component of cell Data
for analysis. 

Lines 383 to 388 provides the instruction what to do to run the code for getting posteriors and
the spatial prediction. 
Lines 389 to line 400 provides the code for extracting and saving the posteriors for the time at four 
locations as .txt files in the desired directory. 
Lines 407 to 473 continues with the Alaska data example for multiple time point predictions at 16 locations.
The predictive density plots, with credible intervals and indication of true values via black horizontal lines
are provided in this part. 

----------------------------------------
Another example for time series reconstruction at spatial locations
----------------------------------------
After runnig Bayesian_updates.m and spatial_prediction.m list and list1 are obtained. 
Lines 482 to 494 extracts the simulated observations for the complete time series at 
desired locations and save them in .txt files.


%%%%%%%%%%%%%% R Code %%%%%%%%%%%%%%%%%%%%%%%%%
The following two codes are used for purpose of making colored hpd plots.

hpd_main.R
-----------
This function produces the hpd plot with the magnitude of density being proportional 
to the brightness of the color. 

colorplot_hpd.R
-----------------------------
This function calls the ranjanda2.R as the source code and used on the desired data sets. 
This function also saves the hpd color plots in the desired directory. 
The examples are given within the code for simulated data, for Alaska temp data and for Sea temperature data. 
All the lines are intentionally commented out. If anyone wants to use any particular example can uncomment the
corresponding sections. 

-----------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------
Detrended Alaska temperature data and the locations are given in the 
detrended_ALASKAdata.csv and USA_locations.csv file. The third and forth column
of USA_locations contains the locations after Lambert transformation. 

Detrended Sea temperature data and its locations after Lambert tranformation
are given in detrended_Seatemp_data.csv and Sea_temp_locations.csv files, respectively. 



 







 





 
