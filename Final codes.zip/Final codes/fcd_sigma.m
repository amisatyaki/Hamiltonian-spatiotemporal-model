function sigma = fcd_sigma(alpha_v, gamma_v, zeta, m,T)

%s=Data{1,1};
%m=size(s);
%m=m(1);

%x=Data{1,3};

%Omega0=delta_omega0(eta1,Data,m);

scale = gamma_v/2 + 2*zeta;
shape = alpha_v+m*T;
k=gamrnd(shape,1./scale);
sigma = sqrt(1./k);