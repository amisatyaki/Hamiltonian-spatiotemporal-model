#col2rgbfunc <- function(color = "red", alpha = 1) rgb(1,0,0,alpha=alpha)#rgb(t(col2rgb(color))/255, alpha = alpha)
col2rgbfunc <- function(color = "maroon", alpha = 1) rgb(0.6901961, 0.1882353, 0.3764706,alpha=alpha) #rgb(0.6901961, 0.1882353, 0.3764706,alpha=alpha)#rgb(t(col2rgb(color))/255, alpha = alpha)
#col2rgbfunc <- function(color = "maroon", alpha = 1) rgb(0,0,0,alpha=alpha)#rgb(t(col2rgb(color))/255, alpha = alpha)


parallel.empirical.plot <- function(x.data, plcolor = "red", Ncl = Ncl, plot.means = TRUE, a=a, b=b)
{

 tr.lev <- seq(0, 1, length.out = Ncl + 1)

 x.quantiles <- apply(x.data, 2, quantile, probs = tr.lev)

 x.qtl.diff <- x.quantiles[-1, ] - x.quantiles[-nrow(x.quantiles), ]

 x.qtl.diff <- as.matrix(x.qtl.diff)

 min.diffs <- apply(x.qtl.diff, 2, min)

dim1<-dim(x.qtl.diff)
for( i in 1:dim1[1] )
{ for( j in 1:dim1[2] )
   { if( x.qtl.diff[i,j]==0 ) x.qtl.diff[i,j]<-exp(-100)
   }
}  

 alpha.vals <- matrix(min.diffs, ncol = ncol(x.qtl.diff), nrow = nrow(x.qtl.diff), by = T)/x.qtl.diff

 dim2<-dim(alpha.vals)
 for( i in 1:dim2[1] )
 { for( j in 1:dim2[2] )
    { if( alpha.vals[i,j]<=0 ) alpha.vals[i,j]<-exp(-100)
    }
 }   

 means <- apply(x.data, 2, mean)

# pdf(file = filename)

 #plot( 1 : (ncol(x.data) + 1), ylim = range(x.data),  type = "n", xlab = "", ylab = "", axes = TRUE)

 #plot( 1 : (ncol(x.data) + 1), ylim = c(a,b), xlim=c(1,100), type = "n", xlab = "", ylab = "", axes = TRUE)
 plot( 1 : (ncol(x.data) + 1), ylim = c(a,b), xlim=c(1,SIZE), type = "n", xlab = "", ylab = "", axes = TRUE)

 #axis(1, at = (1 : ncol(x.data)) + 0.5, labels = 1 : ncol(x.data), xaxs = "i") 
 #axis(2, tick = T, xaxs = "i")
 box()

 for (i in 1:ncol(x.data)) {
   for (j in 1:(nrow(x.quantiles) - 1)) {
     polygon(c(i, i + 1, i + 1, i), x.quantiles[c(j, j, j + 1, j + 1),i], col = col2rgbfunc(plcolor, alpha = 0.99*alpha.vals[j ,i]), border =
NA) }
 }

 #if (plot.means == T) 
# lines(1+0:ncol(x.data), c(means[1], means))

# dev.off()
}


# end of function

# To call this function, we use the following:



# xx <- matrix(rgamma(50000, shape = 5), ncol = 50)
# yy <- matrix(rexp(50000), ncol = 50)
# xx <- cbind(xx, yy)

#parallel.empirical.plot(x.data = xx, plcolor = "maroon", Ncl = 8, filename = "temp.pdf")





#Note that the file temp.pdf will be produced: because of the
#transparencies, we do not have a chance to see this on screen except
#via a pdf file.

#The Ncl stands for different quantiles (Ncl = 10 means we get the
#deciles).

#I believe that this function looks best with large numbers of
#coordinates: the mean is a bit of a hack for lower numbers of
#coordinates.

#You can play with different Ncl's to get a good-looking graph: I think
#moderate values are better. Lower values are too smooth and higher
#values are too rough.

#Also, if the x axis looks too ugly because of many ticks, you may
#consider going in and playing with the ticks.








