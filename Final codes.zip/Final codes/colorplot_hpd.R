source("ranjanda2.R")

########## for simulated data ##############

#ff <- list.files(path="/home/name/***/latent", full.names=TRUE) # the location should be where the posterior of latents are stored
#myfilelist <- lapply(ff, read.table)
#names(myfilelist) <- list.files(path="/home/name/***", full.names=FALSE) # same path as above

#true_data = myfilelist[[1]]
#n = dim(true_data)

#SIZE<-length(2:(n[2]-1))


#names = formatC(seq(1:50), width=2, flag="0") ## Gives a sequence of strings 1 to 50 # number should match with the number of locations


#for(i in 2:51){
#  true = t(true_data[i-1,2:(n[2]-1)])
#  latent_data = t(myfilelist[[i]])

#  mypath <- file.path("/home","name","***",paste("latent_x",names[i-1], ".png", sep = "")) # give the path where the plots should be save

#  png(file=mypath)
#     mytitle = paste("Posterior density of latent process: L",names[i-1])
#     parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 24,a=-35,b=35)
#     par(new=T)
#     plot(true,type="o",pch='*',xlim=c(1,SIZE),ylim=c(-35,35),xlab="",ylab=" ",axes=FALSE,col="black",lwd=3,main=mytitle)
#  dev.off()
#}

######## for Alaska temp data ####################

#ff <- list.files(path="/home/name/***/Alaska/latent", full.names=TRUE) 
# the location should be where the posterior of latents are stored (here it is stored in a folder names latent)
#myfilelist <- lapply(ff, read.table)
#names(myfilelist) <- list.files(path="/home/name/***/Alaska/latent", full.names=FALSE)

# SIZE = 65 # number of time points should be mentioned

#names = formatC(seq(1:30), width=2, flag="0") ## Gives a sequence of strings 1 to 30, number of locations


#for(i in 1:30){
#  true= rep(0,SIZE)
#  latent_data = t(myfilelist[[i]])

#  mypath <- file.path("/home","name","***",paste("latent_x",names[i], ".png", sep = "")) # give the path where the plots should be save

#  png(file=mypath)
#     mytitle = paste("Posterior density of latent process at L",names[i])
#     parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 16,a=-5,b=5)
#     par(new=T)
#     plot(true,type="n",pch='*',xlim=c(1,SIZE),ylim=c(-5,5),xlab="",ylab=" ",axes=FALSE,col="black",lwd=3,main=mytitle)
#  dev.off()
  
#}



######## for Alaska temp data four locations time series reconstruction ####################

#ff <- list.files(path="/home/name/***/Alaska/Fourlocations", full.names=TRUE) 
# the location should be where the posterior of spatial prediction data are stored (here it is stored in a folder names Fourlocations)
#myfilelist <- lapply(ff, read.table)
#names(myfilelist) <- list.files(path="/home/satyaki/Desktop/Sourabh Sir/real_data/Alaska/Fourlocations", full.names=FALSE)

#true_data = read.table('/home","name","***/detrended_true_data.txt',na.strings = "NaN"), # read the true detreded data where is stored
#true_data=t(true_data)
#n = dim(true_data)

# SIZE = 65

#names = formatC(c(25,26,28,30)) # these are locations where the complete time series are reconstructed


#for(i in 1:4){
  #true = t(true_data[i,2:(n[2])])
  #true= rep(0,SIZE)
#  latent_data = t(myfilelist[[i+1]])

#  mypath <- file.path("/home","name","***",paste("location_y",names[i], ".png", sep = "")) # location where they should be saved

#  png(file=mypath)
#     mytitle = paste("Predictive density of temperature at L",names[i])
#     parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 16,a=-15,b=15)
#     par(new=T)
#     plot(true_data[i,2:n[2]],pch='*',xlim=c(1,SIZE),ylim=c(-15,15),xlab="",ylab=" ",axes=FALSE,col="black",lwd=5,main=mytitle)
#  dev.off()
#  
#}

###### for Sea temp data ten locations time series reconstruction ###################

#ff <- list.files(path="/home/name/***/ten locations", full.names=TRUE)
# the location should be where the posterior of spatial prediction data are stored (here it is stored in a folder names ten locations)
#myfilelist <- lapply(ff, read.table)
#names(myfilelist) <- list.files(path="/home/name/***/ten locations", full.names=FALSE)

#true_data = read.table('/home/name/***/ten locations/true_data.txt',na.strings = "NaN") # true_data.txt contains the observed data and it is called from where # it is saved
#n = dim(true_data)

# SIZE = 100

#names = formatC(c(31:40),width=2,flag="0") # Gives a sequence of strings 31 to 40

#for(i in 1:10){
 # #true = t(true_data[i,2:(n[2])])
#  latent_data = t(myfilelist[[i+1]])

#  mypath <- file.path("/home","name",***",paste("location_y",names[i], #".png", sep = "")) # give the path it should be saved

#  png(file=mypath)
#     mytitle = paste("Predictive density of temperature at L",names[i])
#     parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 14,a=-5,b=5)
#     par(new=T)
#     plot(t(true_data[i,1:n[2]]),pch='*',xlim=c(1,SIZE),ylim=c(-5,5),xlab="",ylab=" ",axes=FALSE,col="black",lwd=5,main=mytitle)
#  dev.off()
#  
#}



######## for Sea temp data ####################

#ff <- list.files(path="/home/name/***/latent", full.names=TRUE)
# the location should be where the posterior of spatial prediction data are stored (here it is stored in a folder names latent)
#myfilelist <- lapply(ff, read.table)
#names(myfilelist) <- list.files(path="/home/name/***/latent", full.names=FALSE)



# SIZE = 100 #number of time points specified

#names = formatC(seq(1:40), width=2, flag="0") ## Gives a sequence of strings 1 to 40


#for(i in 1:40){
#  true= rep(0,SIZE)
#  latent_data = t(myfilelist[[i]])

#  mypath <- file.path("/home","name","***",paste("latent_x",names[i], ".png", sep = "")) # path where it should be saved

#  png(file=mypath)
#     mytitle = paste("Posterior density of latent process at L",names[i])
#     parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 24,a=-50,b=50)
#     par(new=T)
#     plot(true,type="n",pch='*',xlim=c(1,SIZE),ylim=c(-50,50),xlab="",ylab=" ",axes=FALSE,col="black",lwd=3,main=mytitle)
#  dev.off()
#  
#}


