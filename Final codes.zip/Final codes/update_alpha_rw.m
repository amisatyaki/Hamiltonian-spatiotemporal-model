function alphastar=update_alpha_rw(sigma_alpha,alphastar,M_s, D,X,y,eta3,sigma,m,T,ridge)


mu = 0;
log_prior = (-(alphastar-mu)^2)/(2*sigma_alpha^2);
alpha = (exp(2*alphastar)-1)/(1+exp(2*alphastar));
log_g = 0;
for t=2:T+1
    Omega = omega_t(y,eta3,alpha, t,m);
    %eig(Omega)
    S = Sigma_data_j(eta3, t-1, M_s, y,m);
%     %e=sort(eig(S),'descend');
%     %cumsum(e/sum(e))
    if (det(Omega)<1e-6)
        Omega = Omega + ridge*eye(m);
    end
    if (det(S)<1e-6)
        S = S + ridge*eye(m);
    end
    log_g = log_g + (-2/sigma^2)*((X(:,t) - alpha^2*X(:,t-1))'/Omega)*...
        (X(:,t)-alpha^2*X(:,t-1)) + (-1/2)*log(det(Omega))+(-2*alpha^2/sigma^2)*...
        X(:,t-1)'*inv(D)*inv(S)*inv(D)*X(:,t-1)+(4*alpha/sigma^2)*y(:,t)'*inv(S)*inv(D)*X(:,t-1);
end

log_denom = log_prior + log_g;

%delta1=alphastar;

epsilon=normrnd(0,1.0);
   delta = alphastar+epsilon;

   log_prior = (-(delta-mu)^2)/(2*sigma_alpha^2);

    alpha = (exp(2*delta)-1)/(1+exp(2*delta));
    %log_g = (-beta^2)*c1+beta*c2;
    log_g = 0;
    for t=2:T+1
        Omega = omega_t(y,eta3,alpha, t,m);
        S = Sigma_data_j(eta3, t-1, M_s, y,m);
        if (det(Omega)<1e-6)
            Omega = Omega + ridge*eye(m);
        end
        if (det(S)<1e-6)
            S = S + ridge*eye(m);
        end
        log_g = log_g + (-2/sigma^2)*((X(:,t) - alpha^2*X(:,t-1))'/Omega)*...
            (X(:,t)-alpha^2*X(:,t-1)) + (-1/2)*log(det(Omega))+(-2*alpha^2/sigma^2)*...
            X(:,t-1)'*inv(D)*inv(S)*inv(D)*X(:,t-1)+(4*alpha/sigma^2)*y(:,t)'*inv(S)*inv(D)*X(:,t-1);
    end
    log_num = log_prior + log_g;
    log_diff = log_num - log_denom;
    pi1 = exp(log_diff);
    if (unifrnd(0,1)<=pi1)
        %if (min(delta)>0)
        alphastar = delta;
        log_denom = log_num;
        %end
        %y0_tilde = phi;
    end
  %%% Give a fwd bkwd transformation %%%%%   
    a2=0.5;
    U = unifrnd(0,1); epsilon = normrnd(0,1);
    if U<=0.5
        delta = alphastar - a2*abs(epsilon);
    else
        delta = alphastar + a2*abs(epsilon);
    end
    
       log_prior = (-(delta-mu)^2)/(2*sigma_alpha^2);

    alpha = (exp(2*delta)-1)/(1+exp(2*delta));
    %log_g = (-beta^2)*c1+beta*c2;
    log_g = 0;
    for t=2:T+1
        Omega = omega_t(y,eta3,alpha, t,m);
        S = Sigma_data_j(eta3, t-1, M_s, y,m);
        if (det(Omega)<1e-6)
            Omega = Omega + ridge*eye(m);
        end
        if (det(S)<1e-6)
            S = S + ridge*eye(m);
        end
        log_g = log_g + (-2/sigma^2)*((X(:,t) - alpha^2*X(:,t-1))'/Omega)*...
            (X(:,t)-alpha^2*X(:,t-1)) + (-1/2)*log(det(Omega))+(-2*alpha^2/sigma^2)*...
            X(:,t-1)'*inv(D)*inv(S)*inv(D)*X(:,t-1)+(4*alpha/sigma^2)*y(:,t)'*inv(S)*inv(D)*X(:,t-1);
    end
    log_num = log_prior + log_g;
    log_diff = log_num - log_denom;
    pi1 = exp(log_diff);
    if (unifrnd(0,1)<=pi1)
        %if (min(delta)>0)
        alphastar = delta;
        log_denom = log_num;
        %end
        %y0_tilde = phi;
    end
 %%% Once more %%%%   
    a2=0.001;
    U = unifrnd(0,1); epsilon = normrnd(0,1);
    if U<=0.5
        delta = alphastar - a2*abs(epsilon);
    else
        delta = alphastar + a2*abs(epsilon);
    end
    
       log_prior = (-(delta-mu)^2)/(2*sigma_alpha^2);

    alpha = (exp(2*delta)-1)/(1+exp(2*delta));
    %log_g = (-beta^2)*c1+beta*c2;
    log_g = 0;
    for t=2:T+1
        Omega = omega_t(y,eta3,alpha, t,m);
        S = Sigma_data_j(eta3, t-1, M_s, y,m);
        if (det(Omega)<1e-6)
            Omega = Omega + ridge*eye(m);
        end
        if (det(S)<1e-6)
            S = S + ridge*eye(m);
        end
        log_g = log_g + (-2/sigma^2)*((X(:,t) - alpha^2*X(:,t-1))'/Omega)*...
            (X(:,t)-alpha^2*X(:,t-1)) + (-1/2)*log(det(Omega))+(-2*alpha^2/sigma^2)*...
            X(:,t-1)'*inv(D)*inv(S)*inv(D)*X(:,t-1)+(4*alpha/sigma^2)*y(:,t)'*inv(S)*inv(D)*X(:,t-1);
    end
    log_num = log_prior + log_g;
    log_diff = log_num - log_denom;
    pi1 = exp(log_diff);
    if (unifrnd(0,1)<=pi1)
        %if (min(delta)>0)
        alphastar = delta;
        %end
        %y0_tilde = phi;
    end
