function list = Bayesian_updates(Data)
% This function updates all the parameters involved in the model
% Also the predicted distribution of y is estimated at s and t
tic
s= Data{1,1};
m=size(s);
m=m(1); % number of spatial points
T = Data{1,2};
n = size(T); 
n=n(1)-1; % number of time points, keep the last observation for prediction
y=Data{1,4}(:,2:n+1); % Data 

ridge = 0.001;

%p=0.5;
%q=0.5;


%list_initials = {beta_old, sigma_old, sigma_theta_old,sigma_p_old,eta1_old,...
%    eta2_old, eta3_old,x0_old,y0_old};

[hyperprior, ~] = initials(s,m);

%%%%%%%%%%% hyperparams %%%%%%%%%%%%%%%%%%
% beta0 = hyperprior{1,1};
sigma_beta = sqrt(300.0);%hyperprior{1,2};
sigma_alpha = sqrt(500);%hyperprior{1,3};
alpha_v = hyperprior{1,4};
gamma_v = hyperprior{1,5};
alpha_theta= hyperprior{1,6};
gamma_theta = hyperprior{1,7};
alpha_p= hyperprior{1,8};
gamma_p = hyperprior{1,9};
% alpha_eta1 = hyperprior{1,10};
% gamma_eta1 = hyperprior{1,11};
% alpha_eta2 = hyperprior{1,12};
% gamma_eta2 = hyperprior{1,13};
% alpha_eta3 = hyperprior{1,14};
% gamma_eta3 = hyperprior{1,15};
%%%%%%%%%%%%%%%%%%%%%% initials %%%%%%%%%%%%%%%%%%

betastar = 0.0; %-1.0986;%list_initials{1,1};
alphastar =0.0; %-0.3905;%list_initials{1,2};
sigma_old = sqrt(1);%list_initials{1,3};
% sigma_theta_old = sqrt(2);%list_initials{1,4};
% sigma_p_old = 1;%list_initials{1,5};
 eta1star = log(20);%normrnd(0,1);%1000; %
 eta2star = log(10);%normrnd(0,1);%1000; %
%  eta3star = log(16);%normrnd(0,1);%1000; %
x0_old = Data{1,3}(:,1);%list_initials{1,9};
y0_old = Data{1,4}(:,1);%list_initials{1,10};
%xi_old = eta3_old;
%phi_old = [eta1_old,eta2_old];


%d1=length(xi_old); % length of the xi vector containing the parameters
%d2=length(phi_old);

X = Data{1,3}(:,1:n+1);%zeros([m,n+1]); %%
X(:,1) = x0_old;

y = [y0_old,y]; 
N= 120000;%250000; % the number of samples generated
M= 95000;%225000; % burning period
[M_s,D] = Ms(s,m);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% prepare for storing %%%%%%%%%%%%%

%xi_final = zeros([d1,N-M]);
%phi_final = zeros([d2,N-M]);

sigma_theta_final = zeros([N-M,1]);
sigma_p_final = zeros([N-M,1]);
sigma_final = zeros([N-M,1]);
beta_final = zeros([N-M,1]);
alpha_final = zeros([N-M,1]);
eta1_final = zeros([N-M,1]);
eta2_final = zeros([N-M,1]);
eta3_final = zeros([N-M,1]);
X_final = zeros([m,n+1,N-M]);
y0_final = zeros(m,N-M);
y_predict= zeros(m,N-M); 
x_predict= zeros(m,N-M); 
%%%%%%%%%%%%%% lets start MCMC %%%%%%%%%%%%%%%%%%
eta1_old = 1;%exp(eta1star); %10;
eta2_old = 1;%exp(eta2star); %5;% 
eta3_old = 14.2981;%(seatemp); %2.0290; (for  Indian temp data) 
%7.0020; (for NLDSTM) %10.5853(For GQN); ; %24.1552; %18.5065; %7.9287;%16, % exp(eta3star);%;
% beta_old = 0.4;
% alpha_old = -0.1;

for i=1:N
    
      
     
     
     %beta_old = (exp(2*betastar)-1)/(exp(2*betastar)+1);%-1+(2*exp(betastar))/(exp(betastar)+1);
%      alpha_old = -0.3; %(exp(2*alphastar)-1)/(1+exp(2*alphastar));
    
     %c=term_c(eta3_old,M_s,y,ridge,m,n);
     %beta_old = fcd_beta(beta0,sigma_beta, sigma_old,c);
      %-1+(2*exp(alphastar))/(1+2*exp(alphastar)); %(exp(2*alphastar)-1)/(exp(2*alphastar)+1); %)
     
    [c1,c2]=term_c(eta3_old,M_s,y,sigma_old,0.01,m,n);
    betastar=update_beta_TMCMC(sigma_beta,betastar,c1,c2);
%     
% %     betastar = update_beta_rw(sigma_beta,betastar,c1,c2);
    beta_old = (exp(2*betastar)-1)/(exp(2*betastar)+1);
%     
% %     alphastar=update_alpha_TMCMC(sigma_alpha,alphastar,M_s, D,X,y,eta3_old,sigma_old,m,n,ridge);
   alphastar=update_alpha_rw(sigma_alpha,alphastar,M_s, D,X,y,eta3_old,sigma_old,m,n,ridge);
% alphastar=update_alpha_MH(sigma_alpha,alphastar,M_s, D,X,y,eta3_old,sigma_old,m,n,ridge);
   alpha_old = (exp(2*alphastar)-1)/(1+exp(2*alphastar));
%     
    Delta0 = delta_omega0(eta2_old,s,m);
    sigma_theta_old = fcd_sigma_theta(alpha_theta, gamma_theta, Delta0,m,...
      y0_old,ridge);
% %     
    Omega0 = delta_omega0(eta1_old,s,m);
    sigma_p_old = fcd_sigma_p(alpha_p, gamma_p, x0_old,Omega0,m,ridge);
% % %     
    Sigma0 = Sigma_data_j(eta3_old, 1, M_s, y,m);
    Omega1 = omega_t(y,eta3_old,alpha_old, 2,m);
    [A,B,C] = matrix_A_B_C(D,Sigma0, Omega0,Omega1,alpha_old, m, sigma_old,... 
       sigma_p_old,0.01);
    x0_old = x_0(A,B,C,X(:,2),y, beta_old,sigma_p_old,0.000001,m);
    X(:,1) = x0_old;
    for t=2:n+1
       Omega = omega_t(y,eta3_old,alpha_old,t,m);
       X(:,t) = x_t(X,m,alpha_old, Omega, sigma_old,t,0.0000001);
    end
% 

% % %     
    zeta = term_zeta(y,X,M_s,D,alpha_old, beta_old,eta3_old,m,n,ridge);
    sigma_old = fcd_sigma(alpha_v, gamma_v, zeta, m,n);
%     
% % %     [phi] = eta1_2_update(y,X, sigma_theta_old,sigma_p_old,phi_old, ...
% % %     alpha_eta1,gamma_eta1,alpha_eta2,gamma_eta2,s,m,ridge);
% % %     phi_old = phi;
% 
% %        eta1star = update_eta1(X,sigma_p_old,eta1star,s,m,ridge);
% %       eta1_old = exp(eta1star);
      eta1star = update_eta1_rw(X,sigma_p_old,eta1star, s,m,0.01);
     eta1_old = exp(eta1star);
% %       
% % %       eta2star = update_eta2(y,sigma_theta_old,eta2star,s,m,ridge);
       eta2star = update_eta2_rw(X,sigma_theta_old,eta2star, s,m,0.01);
      eta2_old = exp(eta2star);
% % %       eta1_old = eta1;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% %
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5%%%
% %       eta3star = update_eta3(y,X,M_s,D, sigma_old, beta_old,alpha_old, eta3star, ...
% %       m,n,ridge);
%       eta3star = update_eta3_rw(y,X,M_s,D,sigma_old, beta_old,alpha_old, eta3star, ...
%       m,n,0.1);
%       eta3_old = exp(eta3star);
% % % %      
% % %       eta2 = update_eta2(y,sigma_theta_old,eta1_old,eta2_old, ...
% % %      alpha_eta1,gamma_eta1,alpha_eta2,gamma_eta2,s,m,ridge);
% % %       eta2_old = eta2;
% % %      
% % %      eta3 = update_eta3(y,X,M_s,D,sigma_old,beta_old,eta3_old,alpha_eta3,gamma_eta3, ...
% % %     m,n,ridge);
% % %     eta3_old = eta3;
% % %     
% % %     eta2_old = phi_old(2);
% % %     
% %     %[xi] = TMCMC_update(y,X,M_s, D,sigma_theta_old,sigma_p_old,beta_old,p,q,...
% %      %   xi_old,alpha_v, gamma_v,alpha_eta1,gamma_eta1,alpha_eta2,gamma_eta2,...
% %     %alpha_eta3,gamma_eta3,d,s,m,n,ridge);
% %     %xi_old = xi;
% %     %sigma_old = sqrt(xi_old(1));
% %     %eta1_old = xi_old(2);
% %     %eta2_old = xi_old(3);
% %     %eta3_old = xi_old(4);
%     
% %      [y0] = update_y0(y,alpha_old, eta2_old, eta3_old, sigma_old,X,M_s,D,...
% %      sigma_theta_old,beta_old,s,m,ridge);
% %      y0_old = y0;
% %      y(:,1) = y0_old;
% 
% %      [y0_old] = update_y0_rw(y,alpha_old, eta2_old, eta3_old, sigma_old,X,M_s,D,...
% %      sigma_theta_old,beta_old,s,m,ridge)
% %      y(:,1) = y0_old;
    
    if (i>M)
        %xi_final(:,i-M)= xi_old;
        S = Sigma_data_j(eta3_old, n+1, M_s, y,m);
        mu = beta_old.*y(:,n+1) + alpha_old.*inv(D)*X(:,n+1);
        y_predict(:,i-M) = mvnrnd(mu,(sigma_old^2/4).*S);
        
        Omega = omega_t([y,y_predict(:,i-M)],eta3_old,alpha_old, n+2,m);
        A = (sigma_old^2/4).*Omega;
        x_predict(:,i-M) = mvnrnd(alpha_old^2*X(:,n+1),A);
        
        beta_final(i-M) = beta_old;
        alpha_final(i-M) = alpha_old;
        sigma_theta_final(i-M) = sigma_theta_old;
        sigma_p_final(i-M) = sigma_p_old;
        sigma_final(i-M) = sigma_old;
        X_final(:,:,i-M)=X;
        y0_final(:,i-M) = y0_old;
        eta1_final(i-M) = eta1_old;
        eta2_final(i-M) = eta2_old;
        eta3_final(i-M) = eta3_old;
        %phi_final(:,i-M) = phi_old;
    end
    %i;
    list = {beta_final,alpha_final, sigma_theta_final,sigma_p_final,sigma_final, eta1_final,...
        eta2_final, eta3_final, X_final,y0_final,y_predict,x_predict};
    %if(det(A)<0)
    %    det(A)
    %    break
    %end
end
%list = {beta_final,sigma_theta_final,sigma_p_final,X_final,xi_final,y0_final};

toc
