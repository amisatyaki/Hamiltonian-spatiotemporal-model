function old_eta3 = simulated_annealing_eta3(Data)
tic
s= Data{1,1};
m=size(s);
m=m(1); % number of spatial points
y=Data{1,4};

[M_s,D] = Ms(s,m);
old_eta3 = 1;
r=0.5;

% hyper-parameters
sigma_beta = sqrt(300.0);
sigma_alpha = sqrt(500.0);
alpha_v=2*50000;
gamma_v=1;
alpha_theta = 1000;
gamma_theta =  780;
alpha_p = 90;
gamma_p = 100;
theta_eta1 = 3;
theta_eta2 = -5;
sigma_eta1 = sqrt(1);
sigma_eta2 = sqrt(1);

N=500;

for l = 1:N

 TEMP=100/log(l+1);

 a=max(old_eta3-r,0);
 b=min(old_eta3+r,200);

 new_eta3=unifrnd(a,b);
 
 % initialize
 old_log_L = 0;
 new_log_L = 0;

 for k = 1:100

    % generation of parameters from their prior distributions 
    alphastar = normrnd(0,sigma_alpha);
    betastar = normrnd(0,sigma_beta);
    sigma=sqrt(1/gamrnd(alpha_v,gamma_v/2,1));
    sigma_theta=sqrt(1/gamrnd(alpha_theta,gamma_theta/2,1));
    sigma_p=sqrt(1/gamrnd(alpha_p,gamma_p/2,1));
    eta1star=normrnd(theta_eta1,sigma_eta1);
    eta2star=normrnd(theta_eta2,sigma_eta2);

    alpha = (exp(2*alphastar)-1)/(exp(2*alphastar)+1);
    beta = (exp(2*betastar)-1)/(exp(2*betastar)+1);
    eta1 = exp(eta1star);
    eta2 = exp(eta2star);


    % generate x0,y0
    
    Delta0 = delta_omega0(eta2,s,m);
    Omega0=delta_omega0(eta1,s,m);
    x0=mvnrnd(zeros([m,1]),sigma_p^2.*Omega0);
    y0=mvnrnd(zeros([m,1]),sigma_theta^2.*Delta0);
    y(:,1)=y0;
    old_x=zeros([m,19+1]);
    new_x=zeros([m,19+1]);
    old_x(:,1) = x0;
    new_x(:,1) = x0;

    % initialize log_L
    old_log_S = 0;
    new_log_S = 0;

    for t=2:20
        Omega = omega_t(y,old_eta3,alpha, t,m);
        A = (sigma^2/4).*Omega;
        if det(A)<1e-6
          A = A+0.01.*eye(m);
        end
        old_x(:,t) = mvnrnd(alpha^2*old_x(:,t-1),A);
        mu = beta.*y(:,t-1) + alpha.*inv(D)*old_x(:,t-1);
        S = Sigma_data_j(old_eta3, t-1, M_s, y,m);
        S = (sigma^2/4).*S;
        if det(S)<1e-6
            S = S+0.01.*eye(m);
        end
	old_log_S = old_log_S  - log(det(S)^(1/2)) -...
                    (y(:,t)-mu)'*inv(S)*(y(:,t)-mu);

        Omega = omega_t(y,new_eta3,alpha, t,m);
        A = (sigma^2/4).*Omega;
        if det(A)<1e-6
          A = A+0.01*eye(m);
        end
        new_x(:,t) = mvnrnd(alpha^2*new_x(:,t-1),A);
        mu = beta.*y(:,t-1) + alpha.*inv(D)*new_x(:,t-1);
        S = Sigma_data_j(new_eta3, t-1, M_s, y,m);
        S = (sigma^2/4).*S;
        if det(S)<1e-6
            S = S+0.01.*eye(m);
        end
	new_log_S = new_log_S - log(det(S)^(1/2)) - ...
                    (y(:,t)-mu)'*inv(S)*(y(:,t)-mu);
    end
    old_log_L = old_log_L+old_log_S; 
    new_log_L = new_log_L + new_log_S;
 end
old_log_L=(old_log_L)/k;
new_log_L=(new_log_L)/k;
%new_log_L - old_log_L

rho=min(exp((new_log_L-old_log_L)/TEMP),1);

u=unifrnd(0,1);
if u<=rho
   old_eta3 = new_eta3;
end
%l
%old_eta3
end

toc
beep on; beep