function list1=spatial_prediction(Data,list,eta3,k)
% This function updates all the parameters involved in the model
% Also the predicted distribution of y is estimated at s and t
tic
s= Data{1,1}; % m locations, last k augmented
%s=[s',s1']'; % augment the new locations
m=size(s); % total no of locations
m=m(1); % total number of spatial points
%k=size(s1); % dimension of locations at which the prediction to be made
%k=k(1); % no of locations at which the prediction to be made

T = Data{1,2};
n = size(T); 
n=n(1)-1; % number of time points

y=Data{1,4}(:,2:n+1); 
%y=y(1:m-1,:); % keep aside the last location for prediction purpose
X=list{1,9}(:,:,25000); % updated latent variables, dim = [m,n+1,1]

%X=list{1,9};

% y1 [k,n+1] obsd data values at k spatial locations which will be predicted
y0_old = Data{1,4}(:,1); % initialize y0 for locations 1 to m-k dim = [m-k,1]


% y_star = mvnrnd(mean(y),diag(var(y)),k); % initial value of ystar dim = [k,n]
% 
% y_star = [y1(:,1),y_star]; % initial value of ystar dim=[k,n+1]

y=[y0_old,y]; 

%x0_old = squeeze(X(:,1,:)); % initialize x0 for locations 1 to m-k dim = [m-k,25000]

%x_star = mvnrnd(mean(squeeze(X(:,:,1))),diag(var(squeeze(X(:,:,1)))),k);
 % initialize value of x_star dim = [k,n+1]

%ridge = 0.0000001;

beta=list{1,1}; 
alpha=list{1,2};
%sigma_theta=list{1,3};
%sigma_p=list{1,4};
sigma=list{1,5};
%eta1=list{1,6};
%eta2=list{1,7};


N= 25000;%250000; % the number of samples generated
M= 10000;%15000;%225000; % burning period
[M_s,D] = Ms(s,m); % calculated using all the locations

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% prepare for storing %%%%%%%%%%%%%

ystar_final = zeros([k,n,N-M]);

%%%%%%%%%%%%%% lets start MCMC %%%%%%%%%%%%%%%%%% 
%eta3_old = 18.5067; %2.0290; % for India temp data
%7.0020; (for NLDSTM) %10.5853(For GQN); ; %18.5065; % for LDSTM
% beta_old = 0.4;
% alpha_old = -0.1;

%y= [y',y_star']';
%X=[X',x_star']';
     
%Xstar = [zeros(m-k,n+1)',x_star']'; % dim = [m,n+1]
%Ystar = [y',y_star']'; % dim = [m,n+1]
    
for i=1:N
    %Xstar(1:m-k,:) = squeeze(X(:,:,i));
    for l=1:k
    
        for j=2:n+1
    %         mu=mean(y(1:end,2:end),2);
    %         S=cov(y(1:end,2:end)');
    %         S11 = S(1:m-k,1:m-k)+0.01*eye(m-k);
    %         S22 = S(m-k+1:end,m-k+1:end);
    %         S12 = S(1:m-k,m-k+1:m);
    %         S21=S12';
    %         a1=S21*inv(S11);
    %         cond_sig = S22 - a1*S12;
    %         cond_mean = mu(m-k+1:m) - a1*(y(1:m-k,j)-mu(1:m-k));
    %         y(m-k+1:m,j) = mvnrnd(cond_mean,cond_sig)';
            ytemp = y(1:m-k+l,:);
            mu = beta(i)*ytemp(:,j-1) + alpha(i).*inv(D(1:m-k+l,1:m-k+l))*...
                X(1:m-k+l,j-1); % dim = [m,1]
    %
            S = (sigma(i)^2/4)*Sigma_data_j(eta3, j-1, M_s(1:m-k+l), ytemp,m-k+l)+0.01*eye(m-k+l); % dim = [m,m]
    %        a1=mvnrnd(mu,S)';
    %        y(m-k+1:m,j) = a1(m-k+1:m);
    %         S11=S(1:m-k,1:m-k)+0.01*eye(m-k); %  dim = [m-k,m-k]
            S11=S(1:m-k+l-1,1:m-k+l-1)+0.01*eye(m-k+l-1);
    %         S22=S(m-k+1:m,m-k+1:m); % dim = [k,k]
            S22 = S(m-k+l,m-k+l); 
    %         S12 = S(1:m-k,m-k+1:m); % dim = [m-k,k]
            S12 = S(1:m-k+l-1,m-k+l);
    %         S21=S12'; % dim = [k,m-k]
            S21=S12';
    %         a1=S21*inv(S11); % dim = [k,m-k]
            a1 = S21*inv(S11);
    %         cond_sig = S22 - a1*S12; % dim = [k,k]
            cond_sig = S22 - a1*S12;
    %         cond_mean = mu(m-k+1:m) - a1*(y(1:m-k,j)-mu(1:m-k)); % dim = [k,1]
            cond_mean = mu(m-k+l) - a1*(y(1:m-k+l-1,j)-mu(1:m-k+l-1));
    %         y(m-k+1:m,j) = mvnrnd(cond_mean,cond_sig)'; % dim = [1,k]        
            y(m-k+l,j) = normrnd(cond_mean,cond_sig);
        end
    Data{1,4} = y;
    X = spatial_updates_X(Data,i,list,eta3);
    list{1,9}(:,:,i) = X;
%         if (i>M)
% %             ystar_final(m-k+l,:,i-M) = y(m-k+l,:);
%         end
    end
    
    if (i>M)
%             ystar_final(m-k+l,:,i-M) = y(m-k+l,:);
        %ypred = y(m-k+1:m,2:end);
        ystar_final(:,:,i-M) = y(m-k+1:m,2:end);
%        save (['/home/satyaki/Desktop/Sourabh Sir/real_data/Sea_temp_data/twenty locations/Y_' num2str(i) '.txt'],'ypred','-ascii')
    end    
%     if (i>M)
%         ystar_final(:,:,i-M) = y(m-k+1:m,:); % 
%     end

     list1 = {ystar_final};
    %if(det(A)<0)
    %    det(A)
    %    break
    %end
        i
end


% for i=1:N
%     %Xstar(1:m-k,:) = squeeze(X(:,:,i));
%     
%     for j=2:n+1
%         mu = beta(i)*y(:,j-1) + alpha(i).*inv(D)*X(:,j-1); % dim = [m,1]
%         %mu = beta(i)*y(:,j-1) + alpha(i).*inv(D)*X(:,j-1); % dim = [m,1]
%         S = (sigma(i)^2/4)*Sigma_data_j(eta3, j-1, M_s, y,m)+0.001*eye(m); % dim = [m,m]
%         a1=mvnrnd(mu,S)';
%         y(m-k+1:m,j) = a1(m-k+1:m);
% %         S11=S(1:m-k,1:m-k)+0.01*eye(m-k); %  dim = [m-k,m-k]
% %         S22=S(m-k+1:m,m-k+1:m); % dim = [k,k]
% %         S12 = S(1:m-k,m-k+1:m); % dim = [m-k,k]
% %         S21=S12'; % dim = [k,m-k]
% %         a1=S21*inv(S11); % dim = [k,m-k]
% %         cond_sig = S22 - a1*S12; % dim = [k,k]
% %         cond_mean = mu(m-k+1:m) - a1*(y(1:m-k,j)-mu(1:m-k)); % dim = [k,1]
% %         y(m-k+1:m,j) = mvnrnd(cond_mean,cond_sig)'; % dim = [1,k]        
%     end
%     Data{1,4} = y;
%     X = spatial_updates_X(Data,i,list,eta3);
%     list{1,9}(:,:,i) = X;
%     
% 
%     if (i>M)
%         ystar_final(:,:,i-M) = y(m-k+1:m,:); % 
%     end
%     i
%     list1 = {ystar_final};
%     %if(det(A)<0)
%     %    det(A)
%     %    break
%     %end
% end


%list = {beta_final,sigma_theta_final,sigma_p_final,X_final,xi_final,y0_final};
toc