function betastar=update_beta_TMCMC(sigma_beta,betastar,c1,c2)


p=0.5;
q=0.5;
%d=length(eta1_0);
%m=length(y0_0);
%y0 = y(:,1);
%x0=X(:,1);
%d=length(eta1_0);

%%%%%%%% Step (a) of the algorithm %%%%%%%%%%
U=unifrnd(0,1,1);
a_j1 = 0.05;

%delta = zeros([d,1]);
%phi=zeros([m,1]);

%log_prior = log_prior_eta1; %+log_prior_eta2;
%log_delta = prodpriordensity(xi_0,alpha_v,gamma_v, ...
%,alpha_eta3,gamma_eta3);
%Delta0 = delta_omega0(eta1_0(2),s,m);
%log_y0 = prior_y0(Delta0,sigma_theta,y0,m,ridge);
%Omega0 = delta_omega0(eta1_0,s,m);
%log_x0= prior_x0(x0,Omega0, sigma_p,ridge,m);
%log_g = prod_all_density(y,X,sqrt(xi_0(1)),M_s,D,xi_0(4),beta,ridge,m,T);
log_prior = (-betastar^2)/(2*sigma_beta^2);
beta = (exp(2*betastar)-1)/(exp(2*betastar)+1);%-1+(2*exp(betastar)/(1+2*exp(betastar)));
log_g = (-beta^2)*c1+beta*c2;
log_denom = log_prior + log_g;
phi_tilde = betastar;
%y0_tilde = y0;
if (U<p) 
   epsilon=normrnd(0,1,1);
   %for j=1:d
	a=unidrnd(2);
	b_j = -1*(a==1)+1*(a==2);
	delta = betastar+b_j*a_j1*abs(epsilon);
	%if (j>d)
    %    phi(j-d) = y0_0(j-d)+b_j*a_j1*abs(epsilon);
    %end
   %end
   %y(:,1) = phi;
   log_prior = (-delta^2)/(2*sigma_beta^2);
    %log_prior = log_prior_eta1;% +log_prior_eta2;
%     log_delta = prodpriordensity(delta,alpha_v,gamma_v, ...
%     alpha_eta1,gamma_eta1,alpha_eta2,gamma_eta2,alpha_eta3,gamma_eta3);
    %Delta0 = delta_omega0(delta(2),s,m);
    %log_y0 = prior_y0(Delta0,sigma_theta,y0,m,ridge);
    %Omega0 = delta_omega0(delta,s,m);
    %log_x0= prior_x0(x0,Omega0, sigma_p,ridge,m);
    %log_g = prod_all_density(y,X,sqrt(delta(1)),M_s,D,delta(4),beta,ridge,m,T);
    beta = (exp(2*delta)-1)/(exp(2*delta)+1);%-1+(2*exp(delta)/(1+2*exp(delta)));
    log_g = (-beta^2)*c1+beta*c2;
    log_num = log_prior + log_g;
    log_diff = log_num - log_denom;
    pi1 = exp(log_diff);
    if (unifrnd(0,1)<=pi1)
        %if (min(delta)>0)
        phi_tilde = delta;
        %end
        %y0_tilde = phi;
    end
end
b=0;
if(U>=p)
   epsilon = unifrnd(-1,1);
   %for j=1:d
       a=unidrnd(3);
       b_j = -1*(a==1) + 0*(a==2)+1*(a==3);
       %if(j<=d)
       delta = betastar*epsilon*(b_j==-1)+(betastar/epsilon)*(b_j==-1)+...
               betastar*(b_j==0);
       %end
       %if (j>d)
       %    phi(j-d) = y0_0(j-d)*epsilon*(b_j==-1)+(y0_0(j-d)/epsilon)*(b_j==-1)+...
       %        y0_0(j-d)*(b_j==0);
       %end
       b=b+b_j;
   %end
   J = abs(epsilon)^b;
   %y(:,1) = phi;
%    log_delta = prodpriordensity(delta,alpha_v,gamma_v, ...
%    alpha_eta1,gamma_eta1,alpha_eta2,gamma_eta2,alpha_eta3,gamma_eta3);
   %[log_prior_eta1,~] = prior_eta1_2([delta,eta2_0],alpha_eta1,gamma_eta1,...
   % alpha_eta2,gamma_eta2);
    %log_prior = log_prior_eta1;% +log_prior_eta2;
   %Delta0 = delta_omega0(delta,s,m);
   %log_y0 = prior_y0(Delta0,sigma_theta,y0,m,ridge);
   %Omega0 = delta_omega0(delta,s,m);
   %log_x0= prior_x0(x0,Omega0, sigma_p,ridge,m);
   %log_g = prod_all_density(y,X,sqrt(delta(1)),M_s,D,delta(4),beta,ridge,m,T);
   log_prior = (-delta^2)/(2*sigma_beta^2);
   beta = (exp(2*delta)-1)/(exp(2*delta)+1);%-1+(2*exp(delta)/(1+2*exp(delta)));
   log_g = (-beta^2)*c1+beta*c2;
   log_num = log_prior + log_g + log(J);
   log_diff = log_num - log_denom;
   pi2 = exp(log_diff);
   if (unifrnd(0,1)<=pi2)
       %if (min(delta)>0)
       phi_tilde = delta;
       %end
        %y0_tilde = phi;
    end
end
%%%%%%%%%%% Step (b) of the algorithm %%%%%%%%%%%%%%%%

%y(:,1)=y0_tilde;
% log_delta = prodpriordensity(phi_tilde,alpha_v,gamma_v, ...
% alpha_eta1,gamma_eta1,alpha_eta2,gamma_eta2,alpha_eta3,gamma_eta3);
% Delta0 = delta_omega0(phi_tilde(3),s,m);
% log_phi = prior_y0(Delta0,sigma_theta,y0,m,ridge);
% Omega0 = delta_omega0(phi_tilde(2),s,m);
% log_x0= prior_x0(X(:,1),Omega0, sigma_p,ridge,m);
% log_g = prod_all_density(y,X,sqrt(phi_tilde(1)),M_s,D,phi_tilde(4),beta,ridge,m,T);
% log_denom = log_delta + log_phi + + log_x0 + log_g;

% [log_prior_eta1,~] = prior_eta1_2([phi_tilde,eta2_0],alpha_eta1,gamma_eta1,...
%     alpha_eta2,gamma_eta2);
% log_prior = log_prior_eta1;% +log_prior_eta2;
%log_delta = prodpriordensity(xi_0,alpha_v,gamma_v, ...
%,alpha_eta3,gamma_eta3);
%Delta0 = delta_omega0(phi_tilde(2),s,m);
%log_y0 = prior_y0(Delta0,sigma_theta,y0,m,ridge);
% Omega0 = delta_omega0(phi_tilde,s,m);
% log_x0= prior_x0(x0,Omega0, sigma_p,ridge,m);
%log_g = prod_all_density(y,X,sqrt(xi_0(1)),M_s,D,xi_0(4),beta,ridge,m,T);
log_prior = (-phi_tilde^2)/(2*sigma_beta^2);
beta = (exp(2*phi_tilde)-1)/(exp(2*phi_tilde)+1);%-1+(2*exp(phi_tilde)/(1+2*exp(phi_tilde)));
log_g = (-beta^2)*c1+beta*c2;
log_denom = log_prior + log_g;

aj_2 = 0.05;

betastar = phi_tilde; 
%y0 = y0_tilde;

U=unifrnd(0,1);
if (U< q)
    U_tilde = unifrnd(0,1);
    epsilon = normrnd(0,1);
    %for j=1:d
    	%if (j<=d)
        delta = (phi_tilde + aj_2*abs(epsilon))*(U_tilde<=0.5) + ...
            (phi_tilde - aj_2*abs(epsilon))*(U_tilde>0.5);
    	%end
    	%if (j>d)
         %  phi(j-d) = (y0_tilde(j-d) + aj_2*abs(epsilon))*(U_tilde<=0.5) + ...
         %   (y0_tilde(j-d) - aj_2*abs(epsilon))*(U_tilde>0.5);
    	%end
    %end
    %y(:,1) = phi;
%     log_delta = prodpriordensity(delta,alpha_v,gamma_v, ...
%     alpha_eta1,gamma_eta1,alpha_eta2,gamma_eta2,alpha_eta3,gamma_eta3);
%     Delta0 = delta_omega0(delta(3),s,m);
%     log_phi = prior_y0(Delta0,sigma_theta,y0,m,ridge);
%     Omega0 = delta_omega0(delta(2),s,m);
%     log_x0 = prior_x0(X(:,1),Omega0, sigma_p,ridge,m);
%     log_g = prod_all_density(y,X,sqrt(delta(1)),M_s,D,delta(4),beta,ridge,m,T);
%     log_num = log_delta + log_phi + + log_x0 + log_g;
%     [log_prior_eta1,~] = prior_eta1_2([delta,eta2_0],alpha_eta1,gamma_eta1,...
%     alpha_eta2,gamma_eta2);
%     log_prior = log_prior_eta1;%+log_prior_eta2;
    %Delta0 = delta_omega0(delta(2),s,m);
    %log_y0 = prior_y0(Delta0,sigma_theta,y0,m,ridge);
%     Omega0 = delta_omega0(delta,s,m);
%     log_x0= prior_x0(x0,Omega0, sigma_p,ridge,m);
   log_prior = (-delta^2)/(2*sigma_beta^2);
   beta = (exp(2*delta)-1)/(exp(2*delta)+1);%-1+(2*exp(delta)/(1+2*exp(delta)));
   log_g = (-beta^2)*c1+beta*c2;    
    log_num = log_prior + log_g;
    log_diff = log_num - log_denom;
    pi3 = exp(log_diff);
    if(unifrnd(0,1)<=pi3)
        %if(min(delta)>0)
       betastar = delta;
        %end
        %y0 = phi;
    end
end

if (U>=q)
    U_tilde = unifrnd(0,1);
    epsilon = unifrnd(-1,1);
    %for j=1:d
    	%if (j<=d)
        delta = (phi_tilde*epsilon)*(U_tilde<=0.5) + ...
            (phi_tilde/epsilon)*(U_tilde>0.5);
    	%end
    	%if (j>d)
         %  phi(j-d) = (y0_tilde(j-d) *epsilon)*(U_tilde<=0.5) + ...
         %   (y0_tilde(j-d)/epsilon)*(U_tilde>0.5);
        %end
	
    %end
    J = abs(epsilon)^(1)*(U_tilde<=0.5) + abs(epsilon)^(-1)*(U_tilde>0.5);
    %y(:,1) = phi;
%     log_delta = prodpriordensity(delta,alpha_v,gamma_v, ...
%     alpha_eta1,gamma_eta1,alpha_eta2,gamma_eta2,alpha_eta3,gamma_eta3);
%     Delta0 = delta_omega0(delta(3),s,m);
%     log_phi = prior_y0(Delta0,sigma_theta,y0,m,ridge);
%     Omega0 = delta_omega0(delta(2),s,m);
%     log_x0 = prior_x0(X(:,1),Omega0, sigma_p,ridge,m);
%     log_g = prod_all_density(y,X,sqrt(delta(1)),M_s,D,delta(4),beta,ridge,m,T);
%     log_num = log_delta + log_phi + log_x0 + log_g + log(J);
%     [log_prior_eta1,~] = prior_eta1_2([delta,eta2_0],alpha_eta1,gamma_eta1,...
%     alpha_eta2,gamma_eta2);
%     log_prior = log_prior_eta1; %+log_prior_eta2;
    %Delta0 = delta_omega0(delta(2),s,m);
    %log_y0 = prior_y0(Delta0,sigma_theta,y0,m,ridge);
    
%     Omega0 = delta_omega0(delta(1),s,m);
%     log_x0= prior_x0(x0,Omega0, sigma_p,ridge,m);
    log_prior = (-delta^2)/(2*sigma_beta^2);
    beta = (exp(2*delta)-1)/(exp(2*delta)+1);%-1+(2*exp(delta)/(1+2*exp(delta)));
    log_g = (-beta^2)*c1+beta*c2;
    log_num = log_prior + log_g + log(J);
    log_diff = log_num - log_denom;
    pi4 = exp(log_diff);    
    if(unifrnd(0,1)<=pi4)
        %if(min(delta)>0)
       betastar = delta;
        %end
        %y0 = phi;
    end    
end
%beta = -1+(2*e^(betastar)/(1+2*e^(betastar)));