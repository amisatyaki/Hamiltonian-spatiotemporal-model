%
eta3 =  5.0581; 
y_multi_predict = multi_predict(Data,list,eta3);
for i=1:7
    y{1,i} = squeeze(y_multi_predict(i,:,:));
end
%
%
for i=1:3
    y{1,7+i} = squeeze(y_multi_predict(10+i,:,:));
end
%
for i=1:3
    y{1,10+i} = squeeze(y_multi_predict(17+i,:,:));
end
%
y{1,14} = squeeze(y_multi_predict(22,:,:));
y{1,15} = squeeze(y_multi_predict(27,:,:));
y{1,16} = squeeze(y_multi_predict(29,:,:));
%
% ymulttrue is the detrended data set for 16 locations at 7 timepoints.
% We have used import tab for importarting this data set in matrix format. 
%
for i=1:16
detrendeddata = detrend(ymulttrue(:,i));
ymulttrue(:,i) = detrendeddata;
end
ymulttrue = ymulttrue(66:end,:)';
%
figure(103)
for k=1:8
    for l=1:6
        subplot(8,6,k*l+(k-1)*(6-l)), [f,x] = ksdensity(y{1,k}(l+1,:)); plot(x,f);
        ylim([0, max(f)])
        hold on 
        L = quantile(y{1,k}(l+1,:),0.025);
        U=quantile(y{1,k}(l+1,:),0.975);
        plot([L,U],[0,0],'r','LineWidth',3)
        plot([ymulttrue(k,l+1),ymulttrue(k,l+1)],[0,max(ylim)],'k','LineWidth',2)
        hold off
    end
end

figure(105)
for k=1:8
    for l=1:6
        subplot(8,6,k*l+(k-1)*(6-l)), [f,x] = ksdensity(y{1,8+k}(l+1,:)); plot(x,f);
        ylim([0, max(f)])
        hold on 
        L = quantile(y{1,8+k}(l+1,:),0.025);
        U=quantile(y{1,8+k}(l+1,:),0.975);
        plot([L,U],[0,0],'r','LineWidth',3)
        plot([ymulttrue(8+k,l+1),ymulttrue(8+k,l+1)],[0,max(ylim)],'k','LineWidth',2)
        hold off
    end
end

