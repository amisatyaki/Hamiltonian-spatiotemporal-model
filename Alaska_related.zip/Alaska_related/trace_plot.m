% this creates trace plots
% takes input from Bayesian_updates.m
%
beta=list{1,1};
alpha=list{1,2};
sigma_theta=list{1,3};
sigma_p=list{1,4};
sigma=list{1,5};
eta1=list{1,6};
eta2=list{1,7};
%
%
figure(1)
subplot(2,4,1), plot(beta); hold on 
t='Trace plot of $\beta$';
title (t,'interpreter','latex')
hold off
subplot(2,4,2), plot(alpha); hold on 
t='Trace plot of $\alpha$';
title (t,'interpreter','latex')
hold off
subplot(2,4,3), plot(sigma_theta); hold on 
t='Trace plot of $\sigma_{\theta}$';
title (t,'interpreter','latex')
hold off
subplot(2,4,4), plot(sigma_p); hold on 
t='Trace plot of $\sigma_{p}$';
title (t,'interpreter','latex')
hold off
subplot(2,4,5), plot(sigma); hold on
t='Trace plot of $\sigma$';
title (t,'interpreter','latex')
hold off
subplot(2,4,6), plot(eta1); hold on
t='Trace plot of $\eta_1$';
title (t,'interpreter','latex')
hold off
subplot(2,4,7), plot(eta2); hold on
t='Trace plot of $\eta_2$';
title (t,'interpreter','latex')
hold off

