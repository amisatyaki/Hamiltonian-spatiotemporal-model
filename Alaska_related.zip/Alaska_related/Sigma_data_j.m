function S_j = Sigma_data_j(eta3, j, M_s, y,m)
%
S_j=zeros([m,m]);
for k=1:m
    for l=1:m
        hj=abs(y(k,j)-y(l,j));
        numer = 2*eta3*exp(-eta3*hj^2)*(1-2*eta3*hj^2);
        denom = M_s(k)*M_s(l);
        S_j(k,l) = numer/denom;
    end
end
        
