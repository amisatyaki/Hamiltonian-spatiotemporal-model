function Omega=omega_t(y,eta3,alpha, t,m)
%
%
Omega=zeros([m,m]);
for i=1:m
    for j=1:m
        h0 = abs(y(i,t-1)-y(j,t-1));
        h1 = abs(y(i,t)-y(j,t));
        l01 = abs(y(i,t-1)-y(j,t));
        l10 = abs(y(i,t)-y(j,t-1));
        Sigma_00 = 2*eta3* exp(-eta3*(h0^2))*(1-2*eta3*(h0^2));
        Sigma_11 = 2*eta3* exp(-eta3*(h1^2))*(1-2*eta3*(h1^2)); 
        Sigma_01 = 2*eta3* exp(-eta3*(l01^2))*(1-2*eta3*(l01^2));
        Sigma_10 = 2*eta3* exp(-eta3*(l10^2))*(1-2*eta3*(l10^2));
        Omega(i,j) = alpha^2*Sigma_00 + alpha*Sigma_01+alpha*Sigma_10+Sigma_11;
    end
end

        
