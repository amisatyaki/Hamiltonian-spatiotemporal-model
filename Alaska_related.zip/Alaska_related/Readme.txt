Every codes have to be saved in a same folder. Within that folder
three new folders have to be created, named latent_posterior, 
hpd_color_plot, Fourlocations, hpd_Alaska_temp_four_locations.  	
	1. extract the data set of order 26 x 65 from Alaska temperature 
	2. detrend the data.
	3. concatinet 4 x 65 initial observations at which the complete time series to be predicted.
	4. After performing the above 3 operations, the detrended y data (with initials for the last
		four locations and y0), the initial for the latent variables, the locations after 
		lambert transformation, the number of time points are stored and given in Data.m. Another two 
		data sets, detrended observations for 16 locations for the years 2016 to 2021
		are kept in detrended_data_16locations_last7timepoints.csv, and detrended observations
		for the 4 locations where the complete time series are predicted, are saved as detrended_true_data.txt 
		in the folder Fourlocations. 
	5. Run Bayesian_updates.m to obtain a cell named list.
	6. To plot the hpd color plots for the predictive densities at four locations,
		we run spatial_data_prep_for_hpd_plot.m, which will save the observations from predictive
		densities at four spatial locations for all the times in txt format. They will be saved in
		the folder, named Fourlocations.
		Then run Four_locations_hpd_colotplots.R. This will create the figure 14. 
		The folder Fourlocations contains the true detrended values at these four locations. 
	7. To create the figures 12 and 13, we have to run multi_predict_plot.m
		after importing the detrended true data set for 16 locations at 7 time points. 
		the detrended data set is saved as detrended_data_16locations_last7timepoints.csv
	8. Run the code predictive_density_y_future_time.m to create the figure 11
	9. To create the figure G.2, first run latent_posterior_storing.m, which svaes the 
		observations from the posteriors of the latent variables in the folder latent_posterior
		Then run the code latent_hpd_colorplot.R to have the plots in the figure G.2
	10. Run the code trace_plot.m to get the trace plots of the parameters, which are given in Figure G.1
