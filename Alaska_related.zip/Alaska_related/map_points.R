library(rworldmap)
library(maps)

worldmap <- getMap(resolution = "coarse")
#
loc=read.csv("~/USA_locations.csv",header=FALSE, sep=",")
#
x=loc$V2
y=loc$V1
#
a=c(25,26,28,30)
#
png(file="Alaska.png")
#
plot(worldmap, col = "lightgrey", 
     fill = T, border = "darkgray",
     xlim = c(-60, 120),ylim=c(-25,20),
     bg = "aliceblue",
     asp = 1, wrap=c(-180,180))
#     
points(x[-a],y[-a],col="red",pch=8)
points(x[a],y[a],col="blue",pch=16)
#
dev.off()

