function delta=delta_omega0(eta,s,m)
% This function calculates either Omega0 or Delta0. If we are calculating
% Delta0 then use eta2 otherwise use eta1. 
%
delta=zeros([m,m]);
for i=1:m
    for j=1:m
        k=-eta*(norm(s(i,:)-s(j,:)))^2;
        delta(i,j) = exp(k);
    end
end
