% this converts the locations by Lambert transformation
% for the Alaska temperature data
% it will also store the locations at first position of the cell
% import the USAlocations into matlab in the table format

s=table2array(USAlocations);

s=deg2rad(s);
s1=s(:,1);
s(:,1)=s(:,2);
s(:,2)=s1;
s1=2*sin(pi/4-s(:,2)/2).*sin(s(:,1));
s2=-2*sin(pi/4-s(:,2)/2).*cos(s(:,1));
s=[s1,s2];
Data{1,1}=s;
clear USAlocations s s1 s2 
