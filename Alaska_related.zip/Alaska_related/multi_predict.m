function y_multi_predict = multi_predict(Data,list,eta3)
% 
d=7; % no of predictions
%
s= Data{1,1};
m=size(s);
m=m(1); % number of spatial points
T = Data{1,2};
n = size(T); 
n=n(1)-1;
%
[M_s,D] = Ms(s,m);
%
beta=list{1,1};
alpha=list{1,2};
sigma=list{1,5};
%
%
%
y_predict = list{1,11};
x_predict = list{1,12};
X=list{1,9};
y = Data{1,4};
%
y_predict1 = zeros([m,d,25000]);
y_predict1(:,1,:) = y_predict;
%
x_predict1 = zeros([m,d,25000]);
x_predict1(:,1,:) = x_predict;
%
%
for j=1:25000
    w=y;
    a=X(:,:,j);
    for i=1:d-1
        w=[w,y_predict1(:,i,j)];
%
        a=[a,x_predict1(:,i,j)];
        S = Sigma_data_j(eta3, n+(i+1), M_s, w,m);
        mu = beta(j)*w(:,n+(i+1)) + alpha(j)*inv(D)*a(:,n+(i+1));
        y_predict = mvnrnd(mu,(sigma(j)^2/4).*S);
%
        %w = 
        Omega = omega_t([w,y_predict'],eta3,alpha(j), n+(i+2),m);
        A = (sigma(j)^2/4).*Omega;
        x_predict= mvnrnd(alpha(j)^2*a(:,n+(i+1)),A);

        x_predict1(:,(i+1),j) = x_predict';

        y_predict1(:,(i+1),j) = y_predict'; 
    end
end

y_multi_predict = y_predict1;
