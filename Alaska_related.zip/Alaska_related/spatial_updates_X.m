function X = spatial_updates_X(Data,j,list,eta3)
% This function updates X for the purpose of spatial prediction
s= Data{1,1};
m=size(s);
m=m(1); % number of spatial points
T = Data{1,2};
n = size(T); 
n=n(1)-1; %
y=Data{1,4}(:,2:n+1); % Data 

%%%%%%%%%%%%%%%%%%%%%% initials %%%%%%%%%%%%%%%%%%

beta_old = list{1,1}(j);
alpha_old =list{1,2}(j);
sigma_old = list{1,5}(j);

sigma_p_old = list{1,4}(j);

y0_old = Data{1,4}(:,1);



X = list{1,9}(:,1:n+1,max(1,j-1));%

y = [y0_old,y]; 
N= 1;
[M_s,D] = Ms(s,m);

eta1_old = list{1,6}(j);
eta3_old = eta3;
    Omega0 = delta_omega0(eta1_old,s,m);
    Sigma0 = Sigma_data_j(eta3_old, 1, M_s, y,m);
    Omega1 = omega_t(y,eta3_old,alpha_old, 2,m);    
for i=1:N    
    [A,B,C] = matrix_A_B_C(D,Sigma0, Omega0,Omega1,alpha_old, m, sigma_old,... 
       sigma_p_old,0.01);
    x0_old = x_0(A,B,C,X(:,2),y, beta_old,sigma_p_old,0.000001,m);
    X(:,1) = x0_old;
    for t=2:n+1
       Omega = omega_t(y,eta3_old,alpha_old,t,m);
       X(:,t) = x_t(X,m,alpha_old, Omega, sigma_old,t,0.0000001);
    end
end

