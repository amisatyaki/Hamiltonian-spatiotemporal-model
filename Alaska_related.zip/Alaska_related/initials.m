function [hyperprior,list_initials] = initials(s,m)
% This fn stores the initial values, within this function we specify 
% the hyperparameters as well 


%%%%%%% Specification of hyperpriors %%%%%%%%
beta0 = 0;
sigma_beta = 10.0;
sigma_alpha = sqrt(0.01);
alpha_v=780000;
gamma_v=2;
alpha_theta = 58900;
gamma_theta =  770/2; 
alpha_p = 385; 
gamma_p = 10;
alpha_eta1 = 3;
gamma_eta1 = 0.5;
alpha_eta2 = 3;
gamma_eta2 = 0.5;
alpha_eta3 = 3;
gamma_eta3 = 0.5;
ridge = 0.95;

%%%%%%% Initialization of all the parameters %%%%%%%%%%%%

betastar = normrnd(beta0,sigma_beta);
alphastar = normrnd(0,sigma_alpha);
sigma_old = sqrt(gamrnd(alpha_v,gamma_v)^(-1));
sigma_theta_old = sqrt(gamrnd(alpha_theta,gamma_theta)^(-1));
sigma_p_old = sqrt(gamrnd(alpha_p,gamma_p)^(-1));
eta1_old = sqrt(gamrnd(alpha_eta1,gamma_eta1)^(-1));
eta2_old = sqrt(gamrnd(alpha_eta2,gamma_eta2)^(-1));
eta3_old = sqrt(gamrnd(alpha_eta3,gamma_eta3)^(-1));

%%%%%%%%%%%%% Initialization of matrices %%%%%%%%%

Delta0_old = delta_omega0(eta2_old,s,m);
Delta0_old = Delta0_old + (ridge*eye(m))*(det(Delta0_old)<1e-6);
Omega0_old = delta_omega0(eta1_old,s,m);
Omega0_old = Omega0_old + (ridge*eye(m))*(det(Omega0_old)<1e-6);

%%%%%%%%%%%% Initialization of x0 and y0 %%%%%%%%%%%%%%%

x0_old = mvnrnd(zeros([m,1]),Omega0_old)';
y0_old = mvnrnd(zeros([m,1]),Delta0_old)';

%%%%%%%%%%%%% Store the initials %%%%%%%%%

hyperprior = {beta0, sigma_beta, sigma_alpha, alpha_v,gamma_v,alpha_theta,gamma_theta,...
    alpha_p, gamma_p, alpha_eta1, gamma_eta1, alpha_eta2, gamma_eta2, ... 
    alpha_eta3,gamma_eta3};

list_initials = {betastar, alphastar, sigma_old, sigma_theta_old,sigma_p_old,eta1_old,...
    eta2_old, eta3_old,x0_old,y0_old};

