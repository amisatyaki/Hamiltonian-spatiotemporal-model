Every codes have to be saved in a same folder. Within that folder
three new folders have to be created, named latent_posterior, 
hpd_color_plot, Tenlocations, hpd_Sea_temp_ten_locations.
	1. Import the data set data.txt
	2. Subtract the temporal mean from each of the locations.
	3. Concatinet 10 x 100 data points as initial values for last 10 locations. 
	4. Import locations file 40locations.txt
	5. Transform them using Lambert transformation. 
	6. Save them as a cell called Data.mat
	7. All these operations are done in data_preparation.m and Lambert_transformation.m
	8. Pre-processed data is given as Data.mat (which is a cell, containing 4 cells).
	9. Run Bayesian_update.m to obtain a cell named list.
	10. To plot the hpd color plots for the predictive densities at ten locations,
		we run spatial_data_prep_for_hpd_plot.m, which will save the observations from predictive
		densities at ten spatial locations for all the time pts in txt format. They will be saved in
		the folder, named Tenlocations.
		Then run Ten_locations_hpd_colorplots.R. Plots will be saved in folder hpd_Sea_temp_ten_locations.
		These will create the figure 16. The folder Tenlocations contains the true values (referenced) at these ten locations.
	11. Run the code predictive_density_y_future_time.m to create the figure 15
	12. To create the figure H.2, first run latent_posterior_storing.m, which svaes the 
		observations from the posteriors of the latent variables in the folder latent_posterior
		Then run the code latent_hpd_colorplot.R to have the plots (will be saved in folder hpd_color_plot) in the figure H.2	 
	13. Run the code trace_plot.m to get the trace plots of the parameters, which are given in Figure H.1
	14. To get the figure 17, run location_plot.m	
