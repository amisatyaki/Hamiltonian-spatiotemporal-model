%
eta3 = 14.2981;
k=10;
list1 = spatial_prediction(Data,list,eta3,k)
Ytwenty=list1{1,1}; % the predictive posterior data
dim = size(Ytwenty);
L1=dim(1); % number of locations at which the complete time series are reconstructed
n= dim(2); % number of time points

for k=1:L1
    Y_s1 = Ytwenty(k,2:n,:); % predictive data for location k, time=2:101, all the iterated values
    Y_s1=squeeze(Y_s1); % this made the data two dimensional by squeezing the 1 dimension
    save ('~/Tenlocations/Y_' num2str(l) '.txt'],'Y_s1','-ascii')
end
