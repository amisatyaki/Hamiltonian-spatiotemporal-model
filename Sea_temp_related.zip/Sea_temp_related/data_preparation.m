% avarage reference the observed data, initialize for the
% predicted spatial locations, initialize X, y0 and store them
% in appropriate entries of the cell Data
% import the observations from data.txt in table format
data=table2array(data);
spatial_mean = mean(data,2);
data = data - spatial_mean*ones(1,100);
true_data = data(m-9:m,:);
 
mu = mean(data,1);
sigma=cov(data);

data(m-9:m,:) = mvnrnd(mu,sigma,length(m-9:m));

y0=mvnrnd(mean(data,2),cov(data'),1)';
data=[y0, data];
T=[1:size(data,2)]';

X=mvnrnd(zeros(1,m),eye(m),size(T,1))';

Data{1,2} = T;
Data{1,3}=X;
Data{1,4} = data;

Data{2,1} = spatial_mean;
Data{2,2} = true_data;

clear data mu sigma T m X y0 spatial_mean

save Data


