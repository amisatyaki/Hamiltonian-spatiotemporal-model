% this converts the locations by Lambert transformation and saves as a first 
% entry of the cell Data
% for the Sea temp data
% it will also store the locations at first position of the cell
% import the locations from locations.txt into matlab in the table format

s=table2array(locations);

s=deg2rad(s);

s1=s(:,1); % long
s2=s(:,2); % lat
s(:,1) = 2*sin(pi/4 - s2/2).*sin(s1);
s(:,2) = -2*sin(pi/4 - s2/2).*cos(s1);

Data{1,1}=s;
clear locations s s1 s2
