% Plotting of locations for the sea surface temperature data %%%%%
s=Data{1,1};
plot(s(1:30,1),s(1:30,2),'.r','MarkerSize',15)
hold on
plot(s(31:35,1),s(31:35,2),'.b','MarkerSize',15)
plot(s(36,1),s(36,2),'*k','MarkerSize',8)
plot(s(37:38,1),s(37:38,2),'.b','MarkerSize',15)
plot(s(39,1),s(39,2),'*g','MarkerSize',8)
plot(s(40,1),s(40,2),'.b','MarkerSize',15)
xlabel('s_1')
ylabel('s_2')
t='Location of sea surface temperature after transformation';
title (t,'interpreter','latex')
hold off
