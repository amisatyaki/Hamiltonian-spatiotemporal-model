function sigma_theta = fcd_sigma_theta(alpha_theta, gamma_theta, Delta0,m,y0,ridge)


y=y0;
if det(Delta0)<1e-06
    Delta0=Delta0+ridge*eye(m);
end

scale = (gamma_theta + (y'/(Delta0))*y)/2;
shape = alpha_theta+m/2;
k=gamrnd(shape,1./scale);
sigma_theta = sqrt(1./k);
