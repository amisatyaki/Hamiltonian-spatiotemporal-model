source("ranjanda2.R")

########## for Sea temp data ##############

# the hpd plots will save in a folder called hpd_color_plot within
# the folder Sea_temp_related
# So, a folder named hpd_color_plot has to be created within Sea_temp_related

ff <- list.files(path="~/latent_posterior", full.names=TRUE)
myfilelist <- lapply(ff, read.table)
names(myfilelist) <- list.files(path="~/latent_posterior", full.names=FALSE)



SIZE = 100

names = formatC(seq(1:40), width=2, flag="0") ## Gives a sequence of strings 1 to 30


for(i in 1:40){
  true= rep(0,SIZE)
  latent_data = t(myfilelist[[i]])
#
  mypath <- file.path("/home","satyaki","Sea_temp_related","hpd_color_plot",paste("latent_x",names[i], ".png", sep = ""))
#
  png(file=mypath)
     mytitle = paste("Posterior density of latent process at L",names[i])
     parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 24,a=-50,b=50)
     par(new=T)
     plot(true,type="n",pch='*',xlim=c(1,SIZE),ylim=c(-50,50),xlab="",ylab=" ",axes=FALSE,col="black",lwd=3,main=mytitle)
  dev.off()
}
