function list1=spatial_prediction(Data,list,eta3,k)
% this function generates observations from predictive densities for complete time series at different locations
tic
s= Data{1,1}; % locations
m=size(s); % total no of locations
m=m(1); % total number of spatial points
T = Data{1,2};
n = size(T); 
n=n(1)-1; % number of time points

y=Data{1,4}(:,2:n+1); 
X=list{1,9}(:,:,25000); % 
X=squeeze(X);
y0_old = Data{1,4}(:,1); %


y=[y0_old,y]; 

beta=list{1,1}; 
alpha=list{1,2};
sigma=list{1,5};


N= 25000;%
M= 10000;%
[M_s,D] = Ms(s,m); % 

ystar_final = zeros([k,n,N-M]);

for i=1:N
    for l=1:k
    
        for j=2:n+1
            ytemp = y(1:m-k+l,:);
            mu = beta(i)*ytemp(:,j-1) + alpha(i).*inv(D(1:m-k+l,1:m-k+l))*...
                X(1:m-k+l,j-1); % 
    %
            S = (sigma(i)^2/4)*Sigma_data_j(eta3, j-1, M_s(1:m-k+l), ytemp,m-k+l)+0.01*eye(m-k+l); % 
            S11=S(1:m-k+l-1,1:m-k+l-1)+0.01*eye(m-k+l-1);
            S22 = S(m-k+l,m-k+l); 
            S12 = S(1:m-k+l-1,m-k+l);
            S21=S12';
            a1 = S21*inv(S11);
            cond_sig = S22 - a1*S12;
            cond_mean = mu(m-k+l) - a1*(y(1:m-k+l-1,j)-mu(1:m-k+l-1));
            y(m-k+l,j) = normrnd(cond_mean,cond_sig);
        end
    Data{1,4} = y;
    X = spatial_updates_X(Data,i,list,eta3);
    list{1,9}(:,:,i) = X;
    end
    
    if (i>M)
        ystar_final(:,:,i-M) = y(m-k+1:m,2:end);
    end    
     list1 = {ystar_final};
%        i
end
%
toc
