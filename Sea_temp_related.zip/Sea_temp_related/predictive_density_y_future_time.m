% this creates the predictive density plots for 
% y_{T+1} at all the locations
% 
%
y_predict = list{1,11};
y_obsd = Data{1,4}(:,end);
%
%% 
 for k=1:30
     subplot(6,5,k), [f,x] = ksdensity(y_predict(k,:)); plot(x,f);
     ylim([0, max(f)])
     hold on
     L = quantile(y_predict(k,:),0.025);
     U=quantile(y_predict(k,:),0.975);
     plot([L,U],[0,0],'r','LineWidth',3)
     plot([y_obsd(k),y_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
     hold off
%     
 end
