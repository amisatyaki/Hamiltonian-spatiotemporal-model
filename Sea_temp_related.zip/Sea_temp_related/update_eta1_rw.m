function eta1star = update_eta1_rw(X,sigma_p,eta1star, s,m,ridge)

mu=-3.0;
sigma=sqrt(1);
x0=X(:,1);
log_prior = -(eta1star-mu)^2/(2*sigma^2);
eta1 = exp(eta1star);
Omega0 = delta_omega0(eta1,s,m);
log_x0= prior_x0(x0,Omega0, sigma_p,ridge,m);

log_denom = log_prior + log_x0;


   epsilon=normrnd(0,0.5);
   delta = eta1star+epsilon;
	
   log_prior = -(delta-mu)^2/(2*sigma^2);
   eta1 = exp(delta);
   Omega0 = delta_omega0(eta1,s,m);
   log_x0= prior_x0(x0,Omega0, sigma_p,ridge,m);
   
    log_num = log_prior + log_x0;
    log_diff = log_num - log_denom;
    pi1 = exp(log_diff);
    if (unifrnd(0,1)<=pi1)
            eta1star = delta;
            log_denom = log_num;
    end
 %%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%
 a2=0.005;
    U = unifrnd(0,1); epsilon = normrnd(0,1);
    if U<=0.5
        delta = eta1star - a2*abs(epsilon);
    else
        delta = eta1star + a2*abs(epsilon);
    end
    log_prior = -(delta-mu)^2/(2*sigma^2);
   eta1 = exp(delta);
   Omega0 = delta_omega0(eta1,s,m);
   log_x0= prior_x0(x0,Omega0, sigma_p,ridge,m);
   
    log_num = log_prior + log_x0;
    log_diff = log_num - log_denom;
    pi1 = exp(log_diff);
    if (unifrnd(0,1)<=pi1)
        eta1star = delta;
        log_denom = log_num;
    end
%
    %%%%%%%%%%%%%%%  %%%%%%%
%    
%    
 a2=0.005/2;
    U = unifrnd(0,1); epsilon = normrnd(0,1);
    if U<=0.5
        delta = eta1star - a2*abs(epsilon);
    else
        delta = eta1star + a2*abs(epsilon);
    end
    log_prior = -(delta-mu)^2/(2*sigma^2);
   eta1 = exp(delta);
   Omega0 = delta_omega0(eta1,s,m);
   log_x0= prior_x0(x0,Omega0, sigma_p,ridge,m);
   
    log_num = log_prior + log_x0;
    log_diff = log_num - log_denom;
    pi1 = exp(log_diff);
    if (unifrnd(0,1)<=pi1)
        eta1star = delta;
    end

