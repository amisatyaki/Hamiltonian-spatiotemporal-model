###### for Sea temp data twenty locations time series reconstruction ###################
# create a folder called hpd_Sea_temp_ten_locations
ff <- list.files(path="~/Sea_temp_related/Tenlocations", full.names=TRUE)
myfilelist <- lapply(ff, read.table)
names(myfilelist) <- list.files(path="~/Sea_temp_related/Tenlocations", full.names=FALSE)
#
true_data = read.table('~/Sea_temp_related/Tenlocations/true_data.txt',na.strings = "NaN")
n = dim(true_data)
SIZE = 100
#
names = formatC(c(31:40),width=2,flag="0") # Gives a sequence of strings 31 to 40
#
for(i in 1:10){
  latent_data = t(myfilelist[[i+1]])
#
  mypath <- file.path("/home","satyaki","Sea_temp_related","hpd_Sea_temp_ten_locations",paste("location_y",names[i],".png", sep = ""))
#
  png(file=mypath)
     mytitle = paste("Predictive density of temperature at L",names[i])
     parallel.empirical.plot(x.data = latent_data, plcolor = "maroon", Ncl = 14,a=-5,b=5)
     par(new=T)
     plot(t(true_data[i,1:n[2]]),pch='*',xlim=c(1,SIZE),ylim=c(-5,5),xlab="",ylab=" ",axes=FALSE,col="black",lwd=5,main=mytitle)
  dev.off()
#  
}
