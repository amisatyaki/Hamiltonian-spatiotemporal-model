function [c1,c2]=term_c(eta3,M_s,y,sigma,ridge,m,T)

c1=0; c2=0;
for j=1:T
    S=Sigma_data_j(eta3, j, M_s, y,m);
    a=det(S);
    while (a<1e-6)
        S= S+ ridge*eye(m);
        a= det(S);
    end
    c1=c1+(y(:,j)'/S)*y(:,j);
    c2 = c2+ (y(:,j)'/S)*y(:,(j+1));
end
c1=(2/sigma^2)*c1;
c2 = (4/sigma^2)*c2;
