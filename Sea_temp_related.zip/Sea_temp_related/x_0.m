function x0=x_0(A,B,C,x1,y, beta,sigma_p,ridge,m)
ridge = ridge+1;
%
y0=y(:,1);
y1=y(:,2);
if det(A)<1e-6
    A = A+ridge*eye(m);
end

mu = inv(A)*(B*x1+C*(y1-beta*y0));
sigma = sigma_p^2*inv(A);
[V,D] = eig(sigma);
if (min(D)<0)
    print("error")
end
halfsigma = V*D^(1/2)*V';
Z = mvnrnd(zeros([m,1]),eye(m))';
x0 = mu+halfsigma*Z;
