function zeta = term_zeta(y,X,M_s,D,alpha,beta,eta3,m,T,ridge)
zeta=0;
%
for j=1:T
    mu=beta*y(:,j)+alpha*inv(D)*X(:,j);
    S=Sigma_data_j(eta3, j, M_s, y,m);
    
    a=det(S);
    if a<1e-6
        S=S+ridge*eye(m);
      %  a=det(S);
    end
    z=((y(:,j+1)-mu)'/S)*(y(:,j+1)-mu);
    Omega = omega_t(y, eta3, alpha, j+1,m);
    b=det(Omega);
    if b<1e-6
        Omega = Omega+ridge*eye(m);
    end
    zeta = zeta+z+((X(:,j+1)-alpha^2*X(:,j))'/Omega)*(X(:,j+1)-alpha^2*X(:,j));
end
