clearvars;
addpath("/home/satyaki/Desktop/Sourabh Sir/Code")
%rng(3);
m=50; % number of spatial points
n=20; % number of time points

s1=unifrnd(0,1,[m,1]);
s2=unifrnd(0,1,[m,1]); 

s= [s1,s2]; % random grid points on the square [0,1] x [0,1]

T=1:n; % time points
X=zeros([m,n+1]);
Y=zeros([m,n+1]);

X1 = zeros([m,n+1]);
X2= zeros([m,n+1]);
mu=zeros([m,1]);
mu1=5*ones([m,1]);

S1=sigma_mat(s,1,1);
X1(:,1) = mvnrnd(mu,S1); 

for i=2:(n+1)
    eta = mvnrnd(mu,S1)';
    for j=1:m
        a = mvnrnd(mu,(0.001^2)*eye(m))';
        B = mvnrnd(mu,(0.001^2)*eye(m),m);
	X1(j,i) = a'*X1(:,i-1) + (B'*(X1(:,i-1).^2))'*X1(:,i-1);
    end
    X1(:,i) = X1(:,i)+ eta;
end

S2=sigma_mat(s,1,1);
X2(:,1) = mvnrnd(mu,S2); 

for i=2:(n+1)
    eta = mvnrnd(mu,S2)';
    for j=1:m
        a = mvnrnd(mu,(0.001^2)*eye(m))';
        B = mvnrnd(mu,((0.001)^2)*eye(m),m);
	X2(j,i) = a'*X2(:,i-1) + (B'*(X2(:,i-1).^2))'*X2(:,i-1);
    end
    X2(:,i) = X2(:,i)+ eta;
end

indx=zeros([m,n+1]);
for i=1:(n+1)
	epsilon_1=mvnrnd(mu,S1)';
	phi1_1 = mvnrnd(mu,S1)';
	phi2_1 = mvnrnd(mu,S1)';    
    %epsilon_2=mvnrnd(mu,S2)';
    phi1_2 = mvnrnd(mu1,S2)';
    phi2_2 = mvnrnd(mu1,S2)';
    for j=1:m
        u = unifrnd(0,1,1);
        if (u < 0.6)	
            Y(j,i) =  phi1_1(j) + diag(tan(X1(j,i)))*phi2_1(j) + epsilon_1(j);
            X(j,i) = X1(j,i);
            indx(j,i)=1;
        end
        if (u>=0.6)
            Y(j,i) =  phi1_2(j) + diag(tan(X1(j,i)))*phi2_2(j) + epsilon_1(j);
            X(j,i) = X1(j,i);
        end
    end    	
end
    	    

Data={s,T',X,Y,indx};
save('Data.mat','Data')
clear s*; clear T; clear X1; clear X2; clear X; clear Y; clear epsilon; clear i*; clear j;
clear n; clear m*; clear mu; clear S*; clear a, clear B;
clear p*;  clear e*; clear u;


