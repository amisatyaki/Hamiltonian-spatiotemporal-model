% this will save relevant data to use in R for NGP
% it is written in matlab
% it takes the input Data.mat
%
X=Data{1,3};
Y=Data{1,4};
s=Data{1,1};
%
save('latent_forR.txt','X','-ascii', '-double', '-tabs')
save('response_forR.txt','Y','-ascii', '-double', '-tabs')
save('location.txt','s','-ascii', '-double', '-tabs')
