Every codes have to be saved in a same folder. Within that folder
two new folders have to be created, named latent_posterior and 
hpd_color_plot 	
	1. Use mixture_GQNs.m simulate observations from mixtures of two GQNs
	in matlab
	2. Use store_data_for_R.m for storing the relevant parts of the data
	in .txt format so that it can be used in step 5. 
	3. Run Bayesian_updates.m to get the observations from posteriors 
	and predictive densities. This may take a long time. The outputs 
	will be saved as a cell, named list. 
	4. Use list and Data to create the plots.
	(A)	For trace plot, use trace_plot.m (Figure F.1)
		For predictive density of y_{T+1} use predictive_density_y_future_time.m
		(Figure 6)
		For predictive density of x_{T+1} use predictive_density_x_future_time.m
		(Figure 7)
	(B)	To create the hpd colour plots for the posteriors of latent, do the followings:
		Run commands of latent_posterior_storing.m This will store the observations
		from posterior of latents in the folder latent_posterior
		Next run the commands of latent_hpd_colorplot.R This will store the plots
		in the hpd_color_plot folder. (Figures F.2 and F.3)
	5. Now run the inla_spde_code_mixture_GQN_nonstationary.R
	This will create and save the plots of the predictive densities for y_{T+1}
	and x_{T+1} using nonstationary GP models. The code will also print the
	credible lengths as well. (Figures 8 and 9)
