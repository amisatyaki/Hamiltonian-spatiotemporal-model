function [A,B,C] = matrix_A_B_C(D,Sigma0, Omega0,Omega1,alpha, m, sigma,sigma_p,ridge)
%
%
if det(Sigma0)<1e-6
    Sigma0=Sigma0+ridge*eye(m);
end
if det(Omega0)<1e-6
    Omega0=Omega0+ridge*eye(m);
end
if det(Omega1)<1e-6
    Omega1=Omega1+ridge*eye(m);
end

A = inv(Omega0)+4*(sigma_p^2*alpha^4/sigma^2)*inv(Omega1)+4*(sigma_p^2*alpha^2/sigma^2)*...
    inv(D)*inv(Sigma0)*inv(D);

B = 4*(sigma_p^2*alpha^2/sigma^2)*inv(Omega1);

C = 4*(sigma_p^2*alpha/sigma^2)*inv(D)*inv(Sigma0);

