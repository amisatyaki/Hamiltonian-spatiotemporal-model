% this creates the predictive density plots for 
% y_{T+1} at all the locations
% This also prints the length of the credible intervals
%
y_predict = list{1,11};
y_obsd = Data{1,4}(:,end);
%
%% For simulated data with 50 locations
figure(1)
for k=1:25
     subplot(5,5,k), [f,x] = ksdensity(y_predict(k,:)); plot(x,f);
     ylim([0, max(f)])
     hold on
     L = quantile(y_predict(k,:),0.025);
     U=quantile(y_predict(k,:),0.975);
     plot([L,U],[0,0],'r','LineWidth',3)
     plot([y_obsd(k),y_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
     hold off 
     U-L
end
 figure(2)
 for k=26:50
     subplot(5,5,k-25), [f,x] = ksdensity(y_predict(k,:)); plot(x,f);
     ylim([0, max(f)])
     hold on
     L = quantile(y_predict(k,:),0.025);
     U=quantile(y_predict(k,:),0.975);
     plot([L,U],[0,0],'r','LineWidth',3)
     plot([y_obsd(k),y_obsd(k)],[0,max(ylim)],'k','LineWidth',2)
     hold off   
     U-L
 end

