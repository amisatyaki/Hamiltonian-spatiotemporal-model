function list = Bayesian_updates(Data)
% This function updates all the parameters involved in the model
% Also the predicted distribution of y is estimated at s and t
tic
s= Data{1,1};
m=size(s);
m=m(1); % number of spatial points
T = Data{1,2};
n = size(T); 
n=n(1)-1; % number of time points, keep the last observation for prediction
y=Data{1,4}(:,2:n+1); % Data 

ridge = 0.001;

[hyperprior, ~] = initials(s,m);

%%%%%%%%%%% hyperparams %%%%%%%%%%%%%%%%%%
sigma_beta = sqrt(300.0);
sigma_alpha = sqrt(500);
alpha_v = hyperprior{1,4};
gamma_v = hyperprior{1,5};
alpha_theta= hyperprior{1,6};
gamma_theta = hyperprior{1,7};
alpha_p= hyperprior{1,8};
gamma_p = hyperprior{1,9};
%%%%%%%%%%%%%%%%%%%%%% initials %%%%%%%%%%%%%%%%%%

betastar = 0.0; 
alphastar =0.0; 
sigma_old = sqrt(1);
eta1star = log(20);
eta2star = log(10);
x0_old = Data{1,3}(:,1);
y0_old = Data{1,4}(:,1);


X = Data{1,3}(:,1:n+1);
X(:,1) = x0_old;

y = [y0_old,y]; 
N= 175000;
M= 150000;
[M_s,D] = Ms(s,m);
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% prepare for storing %%%%%%%%%%%%%
%
sigma_theta_final = zeros([N-M,1]);
sigma_p_final = zeros([N-M,1]);
sigma_final = zeros([N-M,1]);
beta_final = zeros([N-M,1]);
alpha_final = zeros([N-M,1]);
eta1_final = zeros([N-M,1]);
eta2_final = zeros([N-M,1]);
eta3_final = zeros([N-M,1]);
X_final = zeros([m,n+1,N-M]);
y0_final = zeros(m,N-M);
y_predict= zeros(m,N-M); 
x_predict= zeros(m,N-M); 
%%%%%%%%%%%%%% lets start MCMC %%%%%%%%%%%%%%%%%%
eta1_old = 1;
eta2_old = 1;
eta3_old = 5.5042; 
%
for i=1:N
%        
    [c1,c2]=term_c(eta3_old,M_s,y,sigma_old,0.01,m,n);
    betastar=update_beta_TMCMC(sigma_beta,betastar,c1,c2);
%     
    beta_old = (exp(2*betastar)-1)/(exp(2*betastar)+1);
%     
   alphastar=update_alpha_rw(sigma_alpha,alphastar,M_s, D,X,y,eta3_old,sigma_old,m,n,ridge);
   alpha_old = (exp(2*alphastar)-1)/(1+exp(2*alphastar));
%     
    Delta0 = delta_omega0(eta2_old,s,m);
    sigma_theta_old = fcd_sigma_theta(alpha_theta, gamma_theta, Delta0,m,...
      y0_old,ridge);
% %     
    Omega0 = delta_omega0(eta1_old,s,m);
    sigma_p_old = abs(fcd_sigma_p(alpha_p, gamma_p, x0_old,Omega0,m,ridge));
% % %     
    Sigma0 = Sigma_data_j(eta3_old, 1, M_s, y,m);
    Omega1 = omega_t(y,eta3_old,alpha_old, 2,m);
    [A,B,C] = matrix_A_B_C(D,Sigma0, Omega0,Omega1,alpha_old, m, sigma_old,... 
       sigma_p_old,0.01);
    x0_old = x_0(A,B,C,X(:,2),y, beta_old,sigma_p_old,0.000001,m);
    X(:,1) = x0_old;
    for t=2:n+1
       Omega = omega_t(y,eta3_old,alpha_old,t,m);
       X(:,t) = x_t(X,m,alpha_old, Omega, sigma_old,t,0.0000001);
    end
% 

% % %     
    zeta = term_zeta(y,X,M_s,D,alpha_old, beta_old,eta3_old,m,n,ridge);
    sigma_old = abs(fcd_sigma(alpha_v, gamma_v, zeta, m,n));
%     
     eta1star = update_eta1_rw(X,sigma_p_old,eta1star, s,m,0.01);
     eta1_old = exp(eta1star);
% %       
       eta2star = update_eta2_rw(X,sigma_theta_old,eta2star, s,m,0.01);
      eta2_old = exp(eta2star);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% %
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5%%%
%    
    if (i>M)
        S = Sigma_data_j(eta3_old, n+1, M_s, y,m);
        mu = beta_old.*y(:,n+1) + alpha_old.*inv(D)*X(:,n+1);
        y_predict(:,i-M) = mvnrnd(mu,(sigma_old^2/4).*S);
        
        Omega = omega_t([y,y_predict(:,i-M)],eta3_old,alpha_old, n+2,m);
        A = (sigma_old^2/4).*Omega;
        x_predict(:,i-M) = mvnrnd(alpha_old^2*X(:,n+1),A);
%        
        beta_final(i-M) = beta_old;
        alpha_final(i-M) = alpha_old;
        sigma_theta_final(i-M) = sigma_theta_old;
        sigma_p_final(i-M) = sigma_p_old;
        sigma_final(i-M) = sigma_old;
        X_final(:,:,i-M)=X;
        y0_final(:,i-M) = y0_old;
        eta1_final(i-M) = eta1_old;
        eta2_final(i-M) = eta2_old;
        eta3_final(i-M) = eta3_old;
    end
    list = {beta_final,alpha_final, sigma_theta_final,sigma_p_final,sigma_final, eta1_final,...
        eta2_final, eta3_final, X_final,y0_final,y_predict,x_predict};

end
toc
