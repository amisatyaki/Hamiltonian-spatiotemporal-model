function eta2star = update_eta2_rw(y,sigma_theta,eta2star,s,m,ridge)
%
y0 = y(:,1);
sigma = sqrt(1);
mu = -5.0;
%
log_prior = -(eta2star-mu)^2/(2*sigma^2);
eta2=exp(eta2star);
Delta0 = delta_omega0(eta2,s,m);
log_y0 = prior_y0(Delta0,sigma_theta,y0,m,ridge);

log_denom = log_prior + log_y0;
%
%
%
   epsilon=normrnd(0,0.5);
	
   delta = eta2star+epsilon;
   log_prior = -(delta-mu)^2/(2*sigma^2);
    eta2=exp(delta);
    Delta0 = delta_omega0(eta2,s,m);
    log_y0 = prior_y0(Delta0,sigma_theta,y0,m,ridge);
%    
    log_num = log_prior + log_y0;
    log_diff = log_num - log_denom;
    pi1 = exp(log_diff);
    if (unifrnd(0,1)<=pi1)
        eta2star = delta;
    end
