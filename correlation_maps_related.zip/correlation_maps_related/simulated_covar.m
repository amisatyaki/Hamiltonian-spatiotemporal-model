function [yvec,s1,s2,simu_covar] = simulated_covar(T,m,K)
% this function will calculate spatio-temporal covariance from the proposed
% model using m spatial and T temporal points. Output will 
% stored as simu_covar. Here K is the number of times m*T spatio-temporal
% values will be generated to calculate the spatio-temporal covariance.
% T=4
% m=10
% K=1000

rng(1);
s1=unifrnd(0,1,[m,1]); 
s2=unifrnd(0,1,[m,1]);
s=[s1,s2]; % m number of spatial points

eta1=1.0; % smoothness parameter of p_s(0)
eta2=1.0; %  smoothness parameter of theta_s(0)
eta3=1.0; %  smoothness parameter of V
sigma_p = sqrt(1); % standard deviation of p_s(0)
sigma_theta = sqrt(1); %sqrt(4); % standard deviation of theta_s(0)
sigma = sqrt(1); %sqrt(2); % standard deviation of V
alpha = 0.9; % coefficient of dynamic movement of latent
beta = 0.9; % coefficient of dynamic movement of observation
%%
Delta0 = delta_omega0(eta2,s,m); % var-cov matrix of theta_s(0)
Omega0=delta_omega0(eta1,s,m); % var-cov matrix of p_s(0)
%%
x0=mvnrnd(zeros([m,1]),sigma_p^2.*Omega0); % generation of p_s(0)
y0=mvnrnd(zeros([m,1]),sigma_theta^2.*Delta0); % generation of theta_s(0)
%%
[M_s,D] = Ms(s,m); % calculation of M_s and the diagonal matrix D containing
                  % M_s as diagonal elements (see definition 5 for M_s)
%%y=zeros([m,T+1]);
y(:,1) = y0;
x=zeros([m,T+1]);
x(:,1) = x0;
%%
yvec= zeros(m*T,K);
%%
for k=1:K
    for t=2:T+1
        S = Sigma_data_j(eta3, t-1, M_s, y,m);
        mu = beta.*y(:,t-1) + alpha.*inv(D)*x(:,t-1);
        y(:,t) = mvnrnd(mu,(sigma^2/4).*S);
        Omega = omega_t(y,eta3,alpha, t,m);
        A = (sigma^2/4).*Omega;
        if det(A)<1e-6
            A = A+0.01*eye(m);
        end
        x(:,t) = mvnrnd(alpha^2*x(:,t-1),A);
    end
    yvec(:,k) = reshape(y(:,2:end),[],1);
end
%% 
simu_covar = cov(yvec');
