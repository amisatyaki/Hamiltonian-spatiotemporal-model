function [yvecexp,SSexp] = simulated_covar_exp(m,K,s1,s2)
% This function computes the spatial covariance at s1, s2 which are used
% earlier for our model, using squared exponential covariance kernel. 
% T = number of time points, used earlier for our model. 
% m= number of locations, used earlier for our model. 
% K = number of simulations, used earlier for our model. 
eta = 1.0; % value of the smoothing parameter
sigmasqr = 1.0; % value of the variance parameter
covarmat = zeros(m,m);
s=[s1,s2];
for i=1:m
    for j=1:m
        covarmat(i,j) = sigmasqr*exp(-eta*(norm(s(i,:)-s(j,:)))^2);
    end
end
yvecexp = zeros(m,K);
muexp=zeros([m,1]);
for j=1:K
    yvecexp(:,j) = mvnrnd(muexp,covarmat);
end
SSexp = cov(yvecexp');
D=diag(diag(SSexp));
Dhalf = sqrt(D);
Dhalfinv=inv(Dhalf);
SScorexp = Dhalfinv*SSexp*Dhalfinv;
heatmap(SScorexp);        

