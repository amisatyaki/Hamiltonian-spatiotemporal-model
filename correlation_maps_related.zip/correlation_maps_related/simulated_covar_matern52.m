function [yvecmatern52,SSmatern52] = simulated_covar_matern52(m,K,s1,s2)
% This function computes the spatial covariance at s1, s2 which are used
% earlier for our model, using matern(3/2) covariance kernel. 
% T = number of time points, used earlier for our model. 
% m= number of locations, used earlier for our model. 
% K = number of simulations, used earlier for our model. 
eta = 1.0; % value of the smoothing parameter
sigmasqr = 1.0; % value of the variance parameter
covarmat = zeros(m,m);
s=[s1,s2];
for i=1:m
    for j=1:m
        covarmat(i,j) = sigmasqr*(1+sqrt(5)*norm(s(i,:)-s(j,:))/eta+5*norm(s(i,:)-s(j,:))^2/(3*eta^2))*...
        exp(-sqrt(5)*norm(s(i,:)-s(j,:))/eta);
    end
end
yvecmatern52 = zeros(m,K);
muexp=zeros([m,1]);
for j=1:K
    yvecmatern52(:,j) = mvnrnd(muexp,covarmat);
end
SSmatern52 = cov(yvecmatern52');
D=diag(diag(SSmatern52));
Dhalf = sqrt(D);
Dhalfinv=inv(Dhalf);
SScormatern52 = Dhalfinv*SSmatern52*Dhalfinv;
heatmap(SScormatern52);