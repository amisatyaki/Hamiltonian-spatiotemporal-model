function simulatedcorrelationmap(simu_covar,T,m)

SScorr=zeros(m,m);
for t=1:T
    MAT = simu_covar((m*(t-1)+1):m*t,(m*(t-1)+1):m*t);
    DMAT = diag(diag(MAT));
    DMAThalf = sqrt(DMAT);
    DMAThalfinv = inv(DMAThalf);
    MAT = DMAThalfinv*MAT* DMAThalfinv;
    SScorr = SScorr + MAT;
end


figure(T+2)
SScorr = SScorr/T;
heatmap(SScorr,'ColorLimits',[0,1])

