Save all the programs in a common folder.
Step1. run simulated_covar.m with T = 4, m=10 and K=1000
Step2. run simulatedcorrelationmap.m with the outputs of simulated_covar.m
Step3. Using the locations of simulated_covar.m  run simulated_covar_exp.m
Step4. Using the locations of simulated_covar.m run simulated_covar_matern32.m
Step5. Using the locations of simulated_covar.m  run simulated_covar_matern52.m
